//

import { injectable } from 'inversify';

//

@injectable()
export abstract class OpaqueExtractor {
  abstract extract(...args: any[]): Promise<any>;
}
