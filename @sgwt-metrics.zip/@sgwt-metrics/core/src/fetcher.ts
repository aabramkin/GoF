//

import { Agent } from 'https';
import { URL } from 'url';

import { inject, injectable, optional } from 'inversify';
import fetch, { Headers, RequestInit, Response } from 'node-fetch';

import { Logger, SilentLogger } from '@sgwt-metrics/logger';

@injectable()
export class Fetcher {
  static BASE_URL = Symbol('BASE_URL');
  static PING_ENDPOINT = Symbol('PING_ENDPOINT');
  static POST_ENDPOINT = Symbol('POST_ENDPOINT');

  constructor(
    @inject(Fetcher.BASE_URL)
    public baseUrl: string,

    @inject(Fetcher.PING_ENDPOINT)
    public pingEndpoint: string,

    @inject(Fetcher.POST_ENDPOINT)
    public postEndpoint: string,

    @inject(fetch)
    @optional()
    public fetchFn = fetch,

    @inject(Logger)
    @optional()
    public log = new SilentLogger()
  ) {
    this.log.silly('Fetcher', 'new');
  }

  async ping(): Promise<Response> {
    this.log.silly('Fetcher', 'ping');
    const url = this.absoluteUrlTo(this.pingEndpoint);
    this.log.verbose('Fetcher', `ping ${url}`);

    const requestOptions: RequestInit = {
      method: 'HEAD',
      timeout: 2500
    };

    const isHttps = (new URL(url)).protocol === 'https';
    this.log.verbose('Fetcher', 'ping', 'isHttps', isHttps);
    if (isHttps) {
      requestOptions.agent = new Agent({rejectUnauthorized: false});
    }

    return this.fetchFn(url, requestOptions);
  }

  async post(data: any): Promise<Response> {
    this.log.silly('Fetcher', 'post', data);
    const url = this.absoluteUrlTo(this.postEndpoint);
    this.log.verbose('Fetcher', `post ${url}`);
    const body = JSON.stringify(data);

    const headers = new Headers();
    headers.append('Accept', 'application/json');
    headers.append('Content-Type', 'application/json');

    const requestOptions: RequestInit = {
      body,
      compress: true,
      headers,
      method: 'POST',
      timeout: 2500
    };

    const isHttps = (new URL(url)).protocol === 'https:';
    this.log.verbose('Fetcher', 'post', 'isHttps', isHttps);
    if (isHttps) {
      requestOptions.agent = new Agent({rejectUnauthorized: false});
    }

    return this.fetchFn(url, requestOptions);
  }

  absoluteUrlTo(path: string) {
    return `${this.baseUrl}${path}`;
  }
}
