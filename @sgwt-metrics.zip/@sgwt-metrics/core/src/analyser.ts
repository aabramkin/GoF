//

import { Container, inject, injectable, optional } from 'inversify';

import { Logger, SilentLogger } from '@sgwt-metrics/logger';

import { EXTRACTOR_TAGS_TOKEN } from './extractor-tags';
import { Fetcher } from './fetcher';
import { OpaqueExtractor } from './opaque-extractor';

//

@injectable()
export class Analyser {

  constructor(
    @inject(Container)
    public injector: Container,

    @inject(Fetcher)
    public fetcher: Fetcher,

    @inject(EXTRACTOR_TAGS_TOKEN)
    @optional()
    public extractors: {[key: string]: symbol} = {},

    @inject(Logger)
    @optional()
    public log = new SilentLogger()
  ) {
    this.log.silly('Analyser', 'new');
  }

  bootstrap(config: any) {
    this.log.silly('Analyser', 'bootstrap', config);

    config.extractors = config.extractors || {};

    const extractorsTagNames = Object.keys(config.extractors);
    this.log.verbose('Analyser', `Run ${extractorsTagNames.length} extractors`);
    this.log.silly('Analyser', 'extractorsTagNames', extractorsTagNames);

    return extractorsTagNames
      .filter(this.isExistingExtractor, this)
      .map(extractorsTagName => {
        const extractor = this.getExtractorByTagName(extractorsTagName);
        const opts = config.extractors[extractorsTagName];

        opts.options = opts.options || {};
        opts.options.cwd = opts.options.cwd || config.cwd || process.cwd();

        // HACK(dduteil092115): pre-bind the extraction function !
        // I pre bind the extract function of each extractor to abstract the
        // option handling. All extractors will be running a opaque
        // extractor.extract() function.
        this.log.verbose('Analyser', `Apply config.extractors.${extractorsTagName} to ${extractor.constructor.name}`);
        extractor.extract = extractor.extract.bind(extractor, opts.target, opts.options);
        return {extractor, name: extractorsTagName};
      });
  }

  async run(extractors: Array<{extractor: OpaqueExtractor, name: string}>) {
    this.log.silly('Analyser', 'run', extractors.length, 'extractors');
    // This will launch all the extraction in concurrence
    const runningExtractors = extractors.map(({extractor, name}) => {
      this.log.verbose('Analyser', extractor.constructor.name, 'extract');
      this.log.profile('Analyser', extractor.constructor.name + 'extract');

      return extractor.extract()
        .catch((error: Error) => {
          this.log.error('Analyser', extractor.constructor.name, 'error\n', error);
          // HACK(dduteil092115): extraction errors are ignored for now
          // We might want to collect them to in a "separate" base to be aware
          // of what is actually going wrong on client computers
          return {};
        })
        .then((extractionResult: any) => {
          this.log.verbose('Analyser', extractor.constructor.name, 'extractionResult', extractionResult);
          this.log.profile('Analyser', extractor.constructor.name + 'extract');
          return {[name]: extractionResult};
        });
    });

    return Promise.all(runningExtractors);
  }

  aggregate(extractorResults: Array<{[name: string]: any}>) {
    this.log.silly('Analyser', 'aggregate', extractorResults);
    return extractorResults
      .reduce((memo, extractorResult) => ({...memo, ...extractorResult}), {});
  }

  getExtractorByTagName(extractorsTagName: string) {
    this.log.silly('Analyser', 'getExtractorByTagName', extractorsTagName);
    const extractorSymbol = this.extractors[extractorsTagName];
    return this.injector.getNamed(OpaqueExtractor, extractorSymbol);
  }

  isExistingExtractor(extractorsTagName: string) {
    this.log.silly('Analyser', 'isExistingExtractor', extractorsTagName);
    const extractorSymbol = this.extractors[extractorsTagName];
    if (!extractorSymbol) {
      throw new Error(`Not recognized extractor tag "${extractorsTagName}"`);
    }
    const isExtractorExist = this.injector.isBoundNamed(OpaqueExtractor, extractorSymbol);

    this.log.silly('Analyser', 'isExtractorExist', isExtractorExist);
    if (!isExtractorExist) {
      const description = String(extractorSymbol).slice(7, -1);
      this.log.info('Analyser', `No extractor found for ${extractorsTagName}: ${description}`);
    }

    return isExtractorExist;
  }

  onExit(code: number) {
    this.log.verbose('Analyser', 'onExit', code);
    this.log.profile('analyse');

    const itWorked = !Boolean(code);
    if (itWorked) {
      this.log.info('Analyser', 'onExit', 'ok');
      return;
    }

    this.log.error('Analyser', 'onExit', 'no ok');
  }
}
