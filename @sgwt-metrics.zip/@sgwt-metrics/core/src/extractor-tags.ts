//

export const EXTRACTOR_TAGS_TOKEN = Symbol('Extractor Tags Token');
