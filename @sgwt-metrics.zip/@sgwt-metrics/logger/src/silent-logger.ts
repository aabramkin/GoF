//

import { injectable } from 'inversify';

import { WinstonLogger } from './winston-logger';

//

@injectable()

export class SilentLogger extends WinstonLogger {
}
