//

import { injectable } from 'inversify';
import { Logger } from 'winston';

//

@injectable()
export class WinstonLogger extends Logger {
}
