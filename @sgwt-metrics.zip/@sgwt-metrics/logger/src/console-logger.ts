//

import { injectable } from 'inversify';
import { ConsoleTransportOptions, transports } from 'winston';

import { WinstonLogger } from './winston-logger';

//

@injectable()
export class ConsoleLogger extends WinstonLogger {
  constructor(level: string = 'silly') {
    super();

    this.level = level;

    const consoleTransportOptions: ConsoleTransportOptions = {
      level
    };
    this.add(transports.Console, consoleTransportOptions);
  }
}
