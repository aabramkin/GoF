//

export const EXTRACTOR_TAGS = {
  env: Symbol('Environment Extractor'),
  pkg: Symbol('Package Json Extractor'),
  pom: Symbol('Project Object Model Extractor'),
  vcs: Symbol('Version Control Tools Extractor')
};
