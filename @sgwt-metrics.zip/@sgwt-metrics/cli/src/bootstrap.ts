//

import * as dedent from 'dedent';
import { Container } from 'inversify';
import { Response } from 'node-fetch';

import { Analyser } from '@sgwt-metrics/core';
import { Logger } from '@sgwt-metrics/logger';

import { rootContainerFactory } from './ioc-config';

//

export function configure(
  config: object,
  overwriteFn: (container: Container) => void = _ => {}
): typeof bootstrap {
  const rootContainer = rootContainerFactory(config);

  const log = rootContainer.get(Logger);
  log.silly('@sgwt-metrics/cli', 'configure analyser');

  overwriteFn(rootContainer);
  log.silly('@sgwt-metrics/cli', 'after user configure fn');

  return bootstrap.bind(null, rootContainer);
}

export function bootstrap(container: Container = rootContainerFactory()): Analyser {
  const log = container.get(Logger);
  log.silly('@sgwt-metrics/cli', 'bootstrap analyser');
  log.silly('@sgwt-metrics/cli', 'bootstrap container', container.guid);

  return container.get(Analyser);
}

export async function launch(analyser: Analyser, config: any) {
  const log = analyser.injector.get(Logger);
  log.silly('@sgwt-metrics/cli', 'launch');
  log.silly('@sgwt-metrics/cli', 'analyser.injector', analyser.injector.guid);

  const fetcher = analyser.fetcher;

  const theServerIsReachable = await fetcher.ping()
    .then(() => true)
    .catch((e: Error) => {
      analyser.log.error('@sgwt-metrics/cli', `fetcher.ping\n`, e.message, '\n', e);
      return false;
    });

  log.silly('@sgwt-metrics/cli', 'server reachable', theServerIsReachable);

  if (!theServerIsReachable) {
    throw new Error(dedent`
      Cannot reach the server when pinging : ${fetcher.absoluteUrlTo(fetcher.pingEndpoint)}
    `);
  }

  const extractors = analyser.bootstrap(config);
  const results = await analyser.run(extractors);
  const aggregatedResult = analyser.aggregate(results);
  await fetcher.post(aggregatedResult)
    .then((resp: Response) => resp.json())
    .catch((e: Error) => {
      analyser.log.error('@sgwt-metrics/cli', `fetcher.post\n`, e.message, '\n', e);
      return {};
    });

  log.verbose('@sgwt-metrics/cli', 'launch', 'fetcher.post done');
  return analyser;
}
