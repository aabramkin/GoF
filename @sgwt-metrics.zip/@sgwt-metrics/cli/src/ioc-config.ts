//

import { Container } from 'inversify';

import { Analyser, EXTRACTOR_TAGS_TOKEN, Fetcher, OpaqueExtractor } from '@sgwt-metrics/core';
import { EnvironmentExtractor } from '@sgwt-metrics/extractor-environment';
import { PackageJsonExtractor } from '@sgwt-metrics/extractor-packagejson';
import { PomExtractor } from '@sgwt-metrics/extractor-pom';
import { VcsExtractor } from '@sgwt-metrics/extractor-vcs';
import { Logger, WinstonLogger } from '@sgwt-metrics/logger';

import { EXTRACTOR_TAGS } from './extractor-tags';

//

export const rootContainerFactory = (config = {} as any) => {
  const container = new Container();

  container.bind(Container).toConstantValue(container);
  container.bind(Analyser).toSelf();
  container.bind(Fetcher).toSelf();
  container.bind<any>(Logger).toConstantValue(new WinstonLogger());

  container.bind(EXTRACTOR_TAGS_TOKEN).toConstantValue(EXTRACTOR_TAGS);
  container.bind(OpaqueExtractor).to(EnvironmentExtractor).whenTargetNamed(EXTRACTOR_TAGS.env);
  container.bind(OpaqueExtractor).to(PackageJsonExtractor).whenTargetNamed(EXTRACTOR_TAGS.pkg);
  container.bind(OpaqueExtractor).to(PomExtractor).whenTargetNamed(EXTRACTOR_TAGS.pom);
  container.bind(OpaqueExtractor).to(VcsExtractor).whenTargetNamed(EXTRACTOR_TAGS.vcs);

  container.bind(Fetcher.BASE_URL).toConstantValue(config.api.baseURL);
  container.bind(Fetcher.PING_ENDPOINT).toConstantValue(config.api.endpoints.ping);
  container.bind(Fetcher.POST_ENDPOINT).toConstantValue(config.api.endpoints.post);

  return container;
};
