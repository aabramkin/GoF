//

import { resolve } from 'path';

import { readFile } from 'fs-extra';
import * as globby from 'globby';
import { inject, injectable, optional } from 'inversify';
import get = require('lodash.get');
import set = require('lodash.set');
import { parseString } from 'xml2js';

import { Logger, SilentLogger } from '@sgwt-metrics/logger';

//

@injectable()
export class PomExtractor {

  constructor(

    @inject(globby)
    @optional()
    private globbyFn = globby,

    @inject(resolve)
    @optional()
    private resolveFn = resolve,

    @inject(readFile)
    @optional()
    private readFileFn = readFile,

    @inject(Logger)
    @optional()
    private log = new SilentLogger()
  ) {
    this.log.silly('PomExtractor', 'new');
  }

  async extract(pattern: string | string[], options: any = {}) {
    this.log.silly('PomExtractor', 'extract', pattern, options);

    options = {...{cwd: process.cwd()}, ...options};

    const files = await this.globbyFn(pattern, options)
      .catch(e => {
        this.log.error('PomExtractor', 'extract\n', e);
        return [];
      });

    this.log.verbose('PomExtractor', 'extract', `Match ${files.length} files`);
    this.log.silly('PomExtractor', 'extract', 'target files: ', files);

    return Promise.all(files.map(async file => {
      const fileContent = await this.readFileFn(this.resolveFn(options.cwd, file), 'utf-8');
      const xmlContent = await new Promise((resolveFn, reject) => {
        parseString(fileContent, (err, data) => err ? reject(err) : resolveFn(data));
      });

      return (options.pick || []).reduce((memo: {}, path: string) => {
        return set(memo, path, get(xmlContent, path));
      }, {});
    }));
  }
}
