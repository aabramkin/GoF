//

import { resolve } from 'path';

import * as globby from 'globby';
import { inject, injectable, optional } from 'inversify';
import * as loadJsonFile from 'load-json-file';
import omit = require('lodash.omit');

import { Logger, SilentLogger } from '@sgwt-metrics/logger';

//

@injectable()
export class PackageJsonExtractor {

  constructor(
    @inject(Logger)
    @optional()
    private log = new SilentLogger(),

    @inject(loadJsonFile)
    @optional()
    private loadJsonFileFn: typeof loadJsonFile = loadJsonFile,

    @inject(globby)
    @optional()
    private globbyFn = globby,

    @inject(resolve)
    @optional()
    private resolveFn = resolve
  ) {
    this.log.silly('PackageJsonExtractor', 'new');
  }

  async extract(pattern: string | string[], options: any = {}) {
    this.log.silly('PackageJsonExtractor', 'extract', pattern, options);

    options = {...{cwd: process.cwd()}, ...options};

    const files = await this.globbyFn(pattern, options)
      .catch(e => {
        this.log.error('PackageJsonExtractor', 'extract\n', e);
        return [];
      });

    this.log.verbose('PackageJsonExtractor', 'extract', `Match ${files.length} files`);
    this.log.silly('PackageJsonExtractor', 'extract', 'target files: ', files);

    return Promise.all(files.map(async file => {
      const jsonContent = await this.loadJsonFileFn(this.resolveFn(options.cwd, file));
      return omit(jsonContent, options.omit);
    }));
  }
}
