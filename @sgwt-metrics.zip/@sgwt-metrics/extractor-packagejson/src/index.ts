
export * from './package-json-extractor';
