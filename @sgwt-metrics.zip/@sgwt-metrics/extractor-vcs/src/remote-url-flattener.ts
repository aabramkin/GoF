//

import pickby = require('lodash.pickby');
import transform = require('lodash.transform');

//

const REMOTE_KEY_MATCHER = /^remote "(.+)"$/;

//

export function remoteUrlFlattener(configData: object) {
  const remoteKeys = pickby(configData, isRemoteKey);
  const flattenRemoteKeys = transform(remoteKeys as {}, mapRemoteAndUrl, {});
  return  {...configData, remoteUrls: flattenRemoteKeys};
}

//

function isRemoteKey(_value: any, configKey: string) {
  return REMOTE_KEY_MATCHER.test(configKey);
}

function mapRemoteAndUrl(memo: any, remote: {url: string}, remoteKey: string) {
  const branchName = remoteKey.replace(REMOTE_KEY_MATCHER, '$1');
  memo[branchName] = remote.url;
  return memo;
}
