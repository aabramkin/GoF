//

import { resolve } from 'path';

import { readFile } from 'fs-extra';
import * as globby from 'globby';
import { parse } from 'ini';
import { inject, injectable, optional } from 'inversify';
import flow = require('lodash.flow');
import omit = require('lodash.omit');

import { Logger, SilentLogger } from '@sgwt-metrics/logger';

import { remoteUrlFlattener } from './remote-url-flattener';

//

@injectable()
export class VcsExtractor {

  constructor(

    @inject(globby)
    @optional()
    private globbyFn = globby,

    @inject(resolve)
    @optional()
    private resolveFn = resolve,

    @inject(readFile)
    @optional()
    private readFileFn = readFile,

    @inject(parse)
    @optional()
    private iniParseFn = parse,

    @inject(Logger)
    @optional()
    private log = new SilentLogger()
  ) {
    this.log.silly('VcsExtractor', 'new');
  }

  async extract(pattern: string | string[], options: any = {}) {
    this.log.silly('VcsExtractor', 'extract', pattern, options);

    options = {...{cwd: process.cwd()}, ...options};

    const files = await this.globbyFn(pattern, options)
      .catch(e => {
        this.log.error('VcsExtractor', 'extract\n', e);
        return [];
      });

    this.log.verbose('VcsExtractor', 'extract', `Match ${files.length} files`);
    this.log.silly('VcsExtractor', 'extract', 'target files: ', files);

    return Promise.all(files.map(async file => {
      const fileContent = await this.readFileFn(this.resolveFn(options.cwd, file), 'utf-8');
      const data = this.iniParseFn(fileContent);
      return flow(
        remoteUrlFlattener,
        subset => omit(subset, options.omit)
      )(data);
    }));
  }
}
