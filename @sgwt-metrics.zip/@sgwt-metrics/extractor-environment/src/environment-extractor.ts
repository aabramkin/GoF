//

import { inject, injectable, optional } from 'inversify';
import omit = require('lodash.omit');

import { Logger, SilentLogger } from '@sgwt-metrics/logger';

//

@injectable()
export class EnvironmentExtractor {

  constructor(
    @inject(Logger)
    @optional()
    private log = new SilentLogger()
  ) {
    this.log.silly('EnvironmentExtractor', 'new');
  }

  extract(target: object, options: any = {}) {
    this.log.verbose('EnvironmentExtractor', 'extract');
    this.log.silly('EnvironmentExtractor', 'extract', target, options);
    return Promise.resolve(omit(target, options.omit));
  }
}
