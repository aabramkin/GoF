import { browser, by, element, ExpectedConditions } from 'protractor';

import { HomePage } from './home.po';

describe('Home Page', () => {
  const homePage = new HomePage();

  beforeAll(() => {
    homePage.navigateTo();
    browser.waitForAngular();
  });

  it('should have a title', async () => {
    const subject = await browser.getTitle();
    const result = 'sg-app';
    expect(subject).toEqual(result);
  });

  it('should have highlight text example', async () => {
    const elementHighlightDirective = homePage.getElementHighlightDirective();
    const subject = await elementHighlightDirective.getCssValue('background-color');
    const result = 'rgba(255, 255, 0, 0.5)';
    expect(subject).toEqual(result);
  });

  it('should have funny pipe example', async () => {
    const elementPipe = homePage.getElementPipe();
    const subject = await elementPipe.getText();
    const result = 'We use ლ(͒ • ꈊ • ͒)ლ ლ(͒ • ꈊ • ͒)ლ Pipe ლ(͒ • ꈊ • ͒)ლ ლ(͒ • ꈊ • ͒)ლ';
    expect(subject).toEqual(result);
  });

  it('should have service example', async () => {
    const elementService = homePage.getElementService();
    const firstElementService = elementService.all(by.css('li')).first();

    const subject = await firstElementService.getText();
    const result = 'Read Turing biography';
    expect(subject).toEqual(result);
  });

  xit('should have i18n integration example', async () => {
    const headerLanguagesDropdown = element(by.css('#sgwt-super-header-languages-dropdown'));

    const links = element(by.css('[aria-labelledby="sgwt-super-header-languages-dropdown"]'))
      .all(by.css('[role="menuitem"]'));
    const [btnEn, btnFr] = [links.get(0), links.get(1)];

    const testi18n = homePage.getElementI18n();
    const getI18nText = () => testi18n.getText();
    const result1 = 'Hey Bienvenue EzWeb TK';
    const result2 = 'Hello EzWeb Tk !';

    await headerLanguagesDropdown.click();
    await btnEn.click();

    expect(await getI18nText()).toEqual(result2);

    await headerLanguagesDropdown.click();
    await btnFr.click();

    expect(await getI18nText()).toEqual(result1);
  });

});
