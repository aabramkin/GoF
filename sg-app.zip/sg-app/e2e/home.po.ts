import { browser, by, element } from 'protractor';

export class HomePage {
  navigateTo() {
    return browser.get('/#/home');
  }

  getElementHighlightDirective() {
    return element(by.css('[data-e2e-highlighted-text]'));
  }

  getElementPipe() {
    return element(by.css('[data-e2e-funny-pipe]'));
  }

  getElementService() {
    return element(by.css('[data-e2e-service-example]'));
  }

  getElementI18n() {
    return element(by.css('[data-e2e-i18n-example]'));
  }
}
