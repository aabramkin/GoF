import { environment } from './environments/environment';

const _paq = window._paq || [];

_paq.push(['setTrackerUrl', environment.piwikBase + '/piwik.php']);
_paq.push(['setSiteId', environment.piwikId]);

_paq.push(['enableLinkTracking']);
_paq.push(['trackPageView']);

if (location.hostname !== 'localhost') {
  addPiwikScript();
}

function addPiwikScript() {
  const pa = document.createElement('script');
  pa.type = 'text/javascript';
  pa.async = true;
  pa.src = environment.piwikBase + '/piwik.js';
  const s = document.getElementsByTagName('script')[0];
  s.parentNode.insertBefore(pa, s);
}
