export const environment = {
  production: true,
  piwikBase: 'http://piwikBase.prod.com',
  piwikId: 'piwikId02'
};
