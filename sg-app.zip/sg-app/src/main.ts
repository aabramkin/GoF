import { enableProdMode } from '@angular/core';
import { platformBrowserDynamic } from '@angular/platform-browser-dynamic';

import { AppModule } from './app/app.module';
import { environment } from './environments/environment';

// Uncomment line 10 for import piwik
// Change environments files for set piwik server and id
// After see https://sgithub.fr.world.socgen/SG-Web-Toolkit/sgwt/tree/master/%40sgwt/analytics-core#step-4---add-some-trackers
// import './piwik';

if (environment.production) {
  enableProdMode();
}

// Uncomment lines 17, 18, and 21 to enable sgwt-connect:
// import { sgwtConnect } from './app/sgwt-connect';
// sgwtConnect.signIn(() => {
// Bootstrap our Angular app with a top level NgModule
platformBrowserDynamic()
  .bootstrapModule(AppModule)
  .catch(console.error);
// });
