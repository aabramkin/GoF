import { HttpClient, HttpClientModule, HttpRequest } from '@angular/common/http';
import { CUSTOM_ELEMENTS_SCHEMA, NgModule } from '@angular/core';
import { FormsModule } from '@angular/forms';
import { BrowserModule } from '@angular/platform-browser';
import { PreloadAllModules, RouterModule } from '@angular/router';
import { TranslateLoader, TranslateModule } from '@ngx-translate/core';
import { TranslateHttpLoader } from '@ngx-translate/http-loader';

import { SGWTConnectModule } from '@sgwt/connect-angular';
import { SGWTUIModule } from '@sgwt/ui-angular';

import { AgGridModule } from 'ag-grid-angular';

import '../styles/styles.scss';

import { AppTranslateModule } from './app-translate.module';
import { AppComponent } from './app.component';
import { ROUTES } from './app.routes';

// App is our top level component

import { ExampleComponent } from './routes/example/example.component';
import { HomeComponent } from './routes/home/home.component';

import { sgwtConnect } from './sgwt-connect';
// App is our top level component
import { ComponentsModule } from './shared/components/components.module';
import { PipesModule } from './shared/pipes/pipes.module';
import { ServicesModule } from './shared/services/services.module';

// Export sgwtConnect factory (AOT requirement):
export function sgwtConnectFactory() {
  return sgwtConnect;
}

// Export sgwtConnect predicate (AOT requirement):
export function sgwtConnectPredicate({url}: HttpRequest<any>) {
  // Only add the Authorization header with your private access_token
  // to requests where url starts with "https://myapi"
  return url.indexOf('https://myapi') === 0;
}

// (window as any)._paq.push(['trackEvent', 'Documentary', 'Play', 'Thrive']);

/**
 * `AppModule` is the main entry point into Angular2's bootstraping process
 */
@NgModule({
  bootstrap: [AppComponent],
  declarations: [
    AppComponent,
    HomeComponent,
    ExampleComponent
  ],
  imports: [ // import Angular's modules
    BrowserModule,
    FormsModule,
    HttpClientModule,
    AppTranslateModule,
    RouterModule.forRoot(ROUTES, {useHash: true, preloadingStrategy: PreloadAllModules}),
    AgGridModule.withComponents([]),
    SGWTConnectModule.forRoot(sgwtConnectFactory, sgwtConnectPredicate),
    SGWTUIModule,
    ComponentsModule,
    ServicesModule,
    PipesModule
  ],
  providers: [ // expose our Services and Providers into Angular's dependency injection

  ],
  schemas: [CUSTOM_ELEMENTS_SCHEMA]
})
export class AppModule {
}
