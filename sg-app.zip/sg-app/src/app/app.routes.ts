import { Routes } from '@angular/router';
import { ExampleComponent } from './routes/example/example.component';
import { HomeComponent } from './routes/home/home.component';

export const ROUTES: Routes = [
  { path: '',      component: HomeComponent },
  { path: 'home',  component: HomeComponent },
  { path: 'example',  component: ExampleComponent },
  { path: '**',    component: HomeComponent }
];
