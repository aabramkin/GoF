import { Component } from '@angular/core';
import { TestBed } from '@angular/core/testing';
import { By } from '@angular/platform-browser';

// Load the implementations that should be tested
import { HighlightTextDirective } from './highlight-text.directive';

describe('highlight-text directive', () => {
  // Create a test component to test directives
  @Component({
    template: '<div whiteappHighlightText>Content</div>'
  })
  class TestComponent { }

  beforeEach(() => {
    // Configure module
    TestBed.configureTestingModule({
      declarations: [
        HighlightTextDirective,
        TestComponent
      ]
    });
  });

  it('should sent background-color to yellow', () => {
    // We create an instance of TestComponent for test it
    const fixture = TestBed.createComponent(TestComponent);
    fixture.detectChanges(); // Trigger data binding

    // We get <div> element
    const element = fixture.debugElement.query(By.css('div'));

    expect(element.nativeElement.style.backgroundColor).toMatch(/rgba\(255, 255, 0/);
  });

});
