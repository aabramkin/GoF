import {
  Directive,
  ElementRef,
  Renderer2
} from '@angular/core';

/*
 * Component
 * A card will compute operation
 */
@Directive({
  selector: '[whiteappHighlightText]'
})
export class HighlightTextDirective {
  constructor(public element: ElementRef, public renderer: Renderer2) {
    renderer.setStyle(element.nativeElement, 'background-color', 'rgba(255,255,0,0.5)');
  }
}
