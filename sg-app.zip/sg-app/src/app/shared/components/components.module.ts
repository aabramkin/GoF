import { NgModule } from '@angular/core';
import { HighlightTextDirective } from './highlight-text/highlight-text.directive';

@NgModule({
  declarations: [
    HighlightTextDirective
  ],
  exports: [
    HighlightTextDirective
  ]
})
export class ComponentsModule { }
