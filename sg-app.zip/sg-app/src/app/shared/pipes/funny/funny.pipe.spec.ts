import { FunnyPipe } from './funny.pipe';

describe('FunnyPipe', () => {

  let pipe;

  beforeEach(() => {
    pipe = new FunnyPipe();
  });

  it('transform a string surround by bear ლ(͒ • ꈊ • ͒)ლ', () => {
    expect(pipe.transform('Pipe test', 1)).toBe('ლ(͒ • ꈊ • ͒)ლ Pipe test ლ(͒ • ꈊ • ͒)ლ');
  });

});
