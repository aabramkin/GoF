import { Pipe, PipeTransform } from '@angular/core';

@Pipe({name: 'funnyPipe'})
export class FunnyPipe implements PipeTransform {
  public transform(value: string, each: number): string {
    return 'ლ(͒ • ꈊ • ͒)ლ '.repeat(each) + value + ' ლ(͒ • ꈊ • ͒)ლ'.repeat(each);
  }
}
