import { NgModule } from '@angular/core';
import { FunnyPipe } from './funny/funny.pipe';

@NgModule({
  declarations: [
    FunnyPipe
  ],
  exports: [
    FunnyPipe
  ]
})
export class PipesModule { }
