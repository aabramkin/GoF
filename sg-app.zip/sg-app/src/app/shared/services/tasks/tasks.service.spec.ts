import { HttpClientTestingModule, HttpTestingController } from '@angular/common/http/testing';
import { TestBed } from '@angular/core/testing';

import { TasksService } from './tasks.service';

describe('TasksService', () => {

  beforeEach(() => TestBed.configureTestingModule({
    providers: [
      TasksService
    ],
    imports: [
      HttpClientTestingModule
    ]
  }));

  it('should get data from the server', () => {
    const taskService = TestBed.get(TasksService);
    const http = TestBed.get(HttpTestingController);
    // fake response
    const expectedTasks = [{id: '132456', value: 'Read Turing biography'}];
    let actualTasks = [];
    taskService.getTasks().subscribe(value => {
      actualTasks = value;
    });
    http.expectOne('/api/tasks').flush(expectedTasks);
    expect(actualTasks).toEqual(expectedTasks);
  });
});
