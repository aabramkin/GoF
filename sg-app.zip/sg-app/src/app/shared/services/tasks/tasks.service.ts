import { HttpClient } from '@angular/common/http';
import { Injectable } from '@angular/core';

// Use this decorator for enable injection in Angular
@Injectable()
export class TasksService {

  constructor(private http: HttpClient) {
  }

  public getTasks() {
    return this.http.get('/api/tasks');
  }

}
