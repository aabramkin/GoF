import { NgModule } from '@angular/core';
import { TasksService } from './tasks/tasks.service';

@NgModule({
  providers: [
    TasksService
  ]
})
export class ServicesModule { }
