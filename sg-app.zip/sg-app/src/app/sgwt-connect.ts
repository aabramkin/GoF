import { setupSGWTConnect } from '@sgwt/connect-angular';

export const sgwtConnect = setupSGWTConnect({
  authorization_endpoint: 'https://sgconnect-hom.fr.world.socgen/sgconnect',
  client_id: '...',
  scope: 'profile openid'
});
