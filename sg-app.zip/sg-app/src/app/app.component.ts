import { AfterViewInit, Component, ElementRef, OnDestroy, ViewChild, ViewEncapsulation } from '@angular/core';
import { TranslateService } from '@ngx-translate/core';
import { IChangeEvent, ISgwtSuperHeader } from 'sgwt-super-header';

@Component({
  selector: 'sg-app-root',
  encapsulation: ViewEncapsulation.None,
  styleUrls: [
    './app.component.scss'
  ],
  templateUrl: './app.component.html'
})
export class AppComponent implements AfterViewInit, OnDestroy {
  @ViewChild('sgwtSuperHeader')
  sgwtSuperHeader: ElementRef;

  constructor(
    public translate: TranslateService
  ) {
    translate.setDefaultLang('en');
    translate.use('en');
  }

  ngAfterViewInit() {
    this.sgwtSuperHeader.nativeElement.addEventListener(
      'sgwt-super-header--language-changed',
      this.onLanguageChanged
    );
  }

  ngOnDestroy() {
    this.sgwtSuperHeader.nativeElement.removeEventListener(
      'sgwt-super-header--language-changed',
      this.onLanguageChanged
    );
  }

  onLanguageChanged = (evt: IChangeEvent) => {
    this.translate.use(evt.detail.language.toLowerCase());
  }
}
