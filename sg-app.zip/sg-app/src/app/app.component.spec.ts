import { Component, ElementRef, Inject } from '@angular/core';
import {
  async,
  ComponentFixture,
  TestBed
} from '@angular/core/testing';
import { MockComponent } from 'ng2-mock-component';

// Load the implementations that should be tested
import { TranslateModule } from '@ngx-translate/core';

import { AppComponent } from './app.component';

//

// tslint:disable-next-line:component-selector
@Component({selector: 'sgwt-super-header', template: ''})
// tslint:disable-next-line:component-class-suffix
class MockSgwtSuperHeader {
  nativeElement: any;
  constructor(el: ElementRef) {
    this.nativeElement = el.nativeElement;
  }
}

//

describe('App', () => {
  beforeEach(() => {
    TestBed.configureTestingModule({
      imports: [TranslateModule.forRoot()],
      declarations: [
        AppComponent,
        MockComponent({selector: 'router-outlet'}),
        MockComponent({selector: 'sgwt-help-center'}),
        MockComponent({selector: 'sgwt-mini-footer'}),
        MockComponent({selector: 'sgwt-mini-header'}),
        MockSgwtSuperHeader
      ]
    })
    .compileComponents(); // compile template and css
  });

  it(`should be ready initialized`, () => {
    // given
    const fixture = TestBed.createComponent(AppComponent);
    const comp = fixture.componentInstance;

    // when
    fixture.detectChanges();

    // then
    expect(fixture).toBeDefined();
    expect(comp).toBeDefined();
  });

});
