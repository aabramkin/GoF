import { Component, OnInit} from '@angular/core';
import { GridOptions } from 'ag-grid/main';

import { sgAgGridConfig } from 'ezweb-customization';

@Component({
  selector: 'sg-app-example',
  styleUrls: [ './example.component.scss' ],
  templateUrl: './example.component.html'
})
export class ExampleComponent implements OnInit {
  public gridOptions: GridOptions;

  email : string;
  pwd : string;

  ngOnInit(){
    this.gridOptions = { ...sgAgGridConfig };
    this.gridOptions.rowData =  [
      {make: 'Тойота', model: 'Celica', price: 35000},
      {make: 'Форд', model: 'Mondeo', price: 32000},
      {make: 'Порше', model: 'Boxter', price: 72000}
    ];
    this.gridOptions.columnDefs = [
      {headerName: 'Производитель', field: 'make'},
      {headerName: 'Модель', field: 'model'},
      {headerName: 'Цена', field: 'price'}
    ];
  }

  onClick() {
    console.log('Login clicked ' + this.email + ' == ' + this.pwd);    
  }
}
