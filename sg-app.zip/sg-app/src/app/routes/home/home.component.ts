import { Component, OnInit } from '@angular/core';

import { TranslateService } from '@ngx-translate/core';
import { TasksService } from 'app/shared';

import { Observable } from 'rxjs/Observable';

import 'rxjs/add/operator/catch';

@Component({
  selector: 'sg-app-home',
  styleUrls: [ './home.component.scss' ],
  templateUrl: './home.component.html'
})
export class HomeComponent implements OnInit {
  tasks$: Observable<any>;

  constructor(public tasksService: TasksService) {}

  public ngOnInit() {
    this.tasks$ = this.tasksService
      .getTasks()
      .catch((err, caught) => {
        console.error(err);
        return [];
      });
  }
}
