import { Pipe, PipeTransform } from '@angular/core';
import { async, ComponentFixture, TestBed } from '@angular/core/testing';
import { TranslateModule } from '@ngx-translate/core';
import { cold, getTestScheduler } from 'jasmine-marbles';

// Load the implementations that should be tested
import { TasksService } from 'app/shared/services/tasks/tasks.service';
import { HomeComponent } from './home.component';

//

@Pipe({name: 'funnyPipe'})
class MockPipe implements PipeTransform {
  transform: () => '';
}

//

describe('Home', () => {
  beforeEach(() => {
    TestBed.configureTestingModule({
      imports: [TranslateModule.forRoot()],
      declarations: [
        HomeComponent,
        MockPipe
      ]
    })
    .compileComponents();
  });

  it('should initialize with given tasks', () => {
    // given
    const tasksService = jasmine.createSpyObj<TasksService>('TasksService', ['getTasks']);
    tasksService.getTasks.and.returnValue(cold('x|', {x: [{value: 'foo'}]}));
    TestBed.overrideComponent(HomeComponent, {
      set: {providers: [{provide: TasksService, useValue: tasksService as any}]}
    });

    const fixture = TestBed.createComponent(HomeComponent);
    const elm = fixture.debugElement.nativeElement as HTMLElement;

    // when
    fixture.detectChanges();

    // then
    expect(elm.querySelector('[data-e2e-service-example]').textContent.trim()).toEqual('');
    expect(tasksService.getTasks).toHaveBeenCalled();

    // Resolve `tasksService.getTasks`
    getTestScheduler().flush();

    // when
    fixture.detectChanges();

    // then
    expect(elm.querySelector('[data-e2e-service-example]').textContent.trim()).toEqual('foo');
  });

});
