/* SystemJS module definition */
declare var module: NodeModule;

interface Window {
  _paq: string[][];
}

interface NodeModule {
  id: string;
}

declare module 'sgwt-super-header' {
  export interface IChangeEvent extends Event {
    detail: {
      language: string;
    }
  }

  export interface ISgwtSuperHeader extends HTMLElement {
    registerCallback(event: string, callback: Function): void;
  }
}
