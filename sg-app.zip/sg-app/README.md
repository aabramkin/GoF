# SGWT Angular 5 Whiteapp

# TL;DR

```bash
# clone our repo
# --depth 1 removes all but one .git commit history
git clone --depth 1 https://sgithub.fr.world.socgen/SG-Web-Toolkit/whiteapp-angular.git

# change directory to our repo
cd whiteapp-angular

npm config set registry https://cdp-nexus-npm.fr.world.socgen/nexus/repository/sgcib-all-cluster-npm-group/

npm install

# start the server
npm start

```

Go to [http://localhost:4200](http://localhost:4200) in your browser.

This whiteapp is mainly using [Angular CLI](https://cli.angular.io).

# Requirement

* [Node 6 (last LTS) with npm 3](https://nodejs.org/en/download/)

## Optional Requirement

* Angular CLI ^1.6.x : `npm i -g @angular/cli@^1.6.0`
* Typescript ^2.4.2 : `npm i -g typescript@^2.4.2`
* Webpack 2.2.x : `npm i -g webpack@2.2`
* Karma : `npm i -g karma`
* Protractor : `npm i -g karma`

# Getting started

## Installing

* `fork` this repo
* `clone` your fork
* `npm install` to install all dependencies
* `npm start` to start the dev server in another tab

## Running the app

After you have installed all dependencies you can now run the app. Run `npm start` to start a local server using `ng serve` which will watch, build (in-memory), and reload for you. The port will be displayed to you as `http://127.0.0.1:4200`.

# Commands

## Run your app
```bash
# development
npm start
# production
npm run build -- --prod
npm run server -- --prod
```

## Run unit tests

```bash
npm test
# With watch
npm test -- --watch
```

## Run end-to-end tests

```bash
# this will start a test server and launch Protractor
npm run e2e
```

## Build files

```bash
# development
npm run build:dev
# production (jit)
npm run build -- --prod
# AoT
npm run build -- --prod --aot
```

# Configuration

Configuration files live in `config/` we are currently using webpack, karma, and protractor for different stages of your application

You have linters configuration too :

* `.htmlhintrc` with [HtmlHint](https://github.com/yaniswang/HTMLHint), view [rules](https://github.com/yaniswang/HTMLHint/wiki/Rules)
* `.sass-lint.yml` with [Sass-lint](https://github.com/sasstools/sass-lint), view [rules](https://github.com/sasstools/sass-lint/tree/master/docs/rules)

# Node mock server

Do you want create a mock api ? No problem !
We use Node and [Expressjs](http://expressjs.com/fr/).

Create a file in `server/api` like this :

```javascript
module.exports = app => {
  app.get('/api/example/data', (req, res) => {
    res.send([
      {name: 'foo', value: 12},
      {name: 'bar', value: 37},
      {name: 'baz', value: 42}
    ]);
  });
};
```

Exprt a function. It's first parameter is the express app. So you can plug on it some endpoint and make what you want.

# File Structure
We use the component approach in our starter. This is the new standard for developing Angular apps and a great way to ensure maintainable code by encapsulation of our behavior logic. A component is basically a self contained app usually in a single file or a folder with each concern as a file: style, template, specs, e2e, and component class. Here's how it looks:
```
your-app/
 ├── config/                        * our configuration
 |   |── .htmlhintrc                * Configuration file for linter html
 |   |── .sass-lint.yml             * Configuration file for sass linter
 |   ├── karma.conf.js              * karma config for our unit tests
 |   ├── protractor.conf.js         * protractor config for our end-to-end tests
 │   └── webpack.config.js          * extra webpack config
 │
 ├── e2e/                           * end-to-end test for folder
 │
 ├── server/                        * our source files for our mock server
 |   ├── api/                       * List of file for our mock api
 |   ├── mocks/                     * List of our mock json file
 │   └── server.js                  * Launcher file for our server
 │
 ├── src/                           * our source files that will be compiled to javascript
 |   ├── index.html                 * Index.html: where we generate our index page
 │   │
 |   ├── main.ts                    * entry file for your app
 │   │
 |   ├── polyfills.ts               * our polyfills file
 │   │
 |   |── styles/                    * Generic styles for your app
 │   │   ├── styles.scss            * Global styles (example html, body etc ..)
 │   │   └── variables.scss         * List of variables
 │   │
 │   ├── app/                       * WebApp: folder
 |   |   ├── routes/                * list of folder for our different app routes
 |   |   ├── shared/                * All Angular elements shared between routes
 │   │   │    ├── components/       * List of components and directives
 │   │   │    ├── pipes/            * List of pipes
 │   │   │    └── services/         * List of services
 │   │   ├── app.component.spec.ts  * a simple test of components in app.component.ts
 │   │   └── app.component.ts       * a simple version of our App component components
 │   │
 │   └── assets/                    * static assets are served here
 │       ├── icon/                  * our list of icons from www.favicon-generator.org
 |       ├── img/                   * our list of images
 |       ├── manifest.json          * Experimental : Manifest.json for describe your app
 │       └── service-worker.js      * Experimental : Service worker
 │
 │
 ├── .npmrc                         * your local npmrc file
 ├── tslint.json                    * typescript lint config
 ├── typedoc.json                   * typescript documentation generator
 ├── tsconfig.json                  * config that webpack uses for typescript
 └── package.json                   * what npm uses to manage it's dependencies

```

## SGConnect

This whiteapp is prepared for sgconnect auth.

Go to `src\sgwt-connect.ts` and change it with your setting.

[More information for SGConnect Endpoint](http://rtd.fr.world.socgen/docs/sgconnect/en/latest/pages/getting_started.html#sgconnect-endpoints)

To enable the connection at the beggining, uncomment code in `src/main.ts`.

[More documentation for @sgwt/connect-angular](https://sgithub.fr.world.socgen/SG-Web-Toolkit/sgwt/tree/master/%40sgwt/connect-angular)


## Notes

#### Where do SASS binary and PhantomJS come from?

To prevent external request (to GitHub for example), we specified in your local `.npmrc` urls to our CDN.
If you want them to vary depending of your environment you can remove this file and use other options.
For example for [Node SASS](https://github.com/sass/node-sass#binary-configuration-parameters) :

```
# For Windows
setx SASS_BINARY_SITE=http://ez-cdn.fr.world.socgen/node-sass

# For Linux
export SASS_BINARY_SITE=http://ez-cdn.fr.world.socgen/node-sass
```

## Tools

* [Angular 2 Tools](https://github.com/angular/angular/blob/master/TOOLS.md)
* [Augury](https://augury.angular.io/)
