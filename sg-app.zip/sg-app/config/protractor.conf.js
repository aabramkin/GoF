// Protractor configuration file, see link for more information
// https://github.com/angular/protractor/blob/master/lib/config.ts

const { SpecReporter } = require('jasmine-spec-reporter');
const { JUnitXmlReporter } = require('jasmine-reporters');

const { app, config, start, stop } = require('../server/server.js');

exports.config = {
  allScriptsTimeout: 11000,
  specs: [
    '../e2e/**/*.e2e-spec.ts'
  ],
  capabilities: {
    browserName: 'chrome',
    chromeOptions: {
      binary: process.env.CHROME_BIN
    }
  },
  directConnect: true,
  baseUrl: 'http://localhost:4200/',
  framework: 'jasmine2',
  jasmineNodeOpts: {
    showColors: true,
    defaultTimeoutInterval: 30000,
    print: function() {}
  },
  beforeLaunch: function() {
    require('ts-node').register({
      project: 'e2e/tsconfig.e2e.json'
    });

    this.server = start(app, config);
  },
  onComplete() {
    stop(this.server);
  },
  onPrepare() {
    jasmine.getEnv().addReporter(
      new SpecReporter({ spec: { displayStacktrace: true } })
    );

    jasmine.getEnv().addReporter(
      new JUnitXmlReporter({
        consolidateAll: true,
        filePrefix: 'protractor-junitresults',
        package: 'e2e',
        savePath: './public/__build__/junit',
        useBrowserName: false
      })
    );
  }
};
