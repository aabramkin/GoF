const path = require('path');

const { AwesomeI18nextPlugin } = require('awesome-i18next-loader');

module.exports = {

  entry: {
    'foo': path.join(__dirname, './foo.js')
  },

  context: path.join(__dirname, '../src'),

  output: {
    path: path.join(__dirname, '../public/__build__'),
    filename: '[name].js'
  },

  plugins: [
    new AwesomeI18nextPlugin({
      dest: 'i18n',
      globs: [
        {
          pattern: '**/locales/**/*.json'
        }
      ],
      defaultLanguages: 'en'
    })
  ]
};

