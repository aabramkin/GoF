// Karma configuration file, see link for more information
// https://karma-runner.github.io/0.13/config/configuration-file.html

module.exports = function (config) {
  var useCoverage = config.angularCli && config.angularCli.codeCoverage;
  var isOnCi = Boolean(process.env.CI);

  config.set({
    basePath: '..',
    frameworks: ['jasmine', '@angular/cli'],
    plugins: [
      require('@angular/cli/plugins/karma'),
      require('karma-chrome-launcher'),
      require('karma-coverage-istanbul-reporter'),
      require('karma-jasmine-html-reporter'),
      require('karma-jasmine'),
      require('karma-junit-reporter')
    ],
    client:{
      clearContext: false // leave Jasmine Spec Runner output visible in browser
    },
    coverageIstanbulReporter: {
      reports: [ 'html', 'lcovonly' ],
      fixWebpackSourcePaths: true
    },
    angularCli: {
      environment: 'dev'
    },
    reporters: isOnCi ? ['dots', 'junit'] : ['progress']
      .concat([useCoverage ? 'coverage-istanbul' : 'kjhtml']),
    port: 9876,
    colors: true,
    logLevel: config.LOG_INFO,
    autoWatch: true,
    browsers: ['ChromeHeadless'],
    singleRun: false,

    junitReporter: {
      outputDir: './public/__build__/junit',
      outputFile: 'karma-junitresults.xml',
      suite: 'unit',
      useBrowserName: false
    }
  });
};
