'use strict';

module.exports = app => {
  app.get('/api/example/data', (req, res) => {
    res.send([
      {name: 'foo', value: 12},
      {name: 'bar', value: 37},
      {name: 'baz', value: 42}
    ]);
  });
};
