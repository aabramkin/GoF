<a name="2.5.7"></a>
## [2.5.7](https://sgithub.fr.world.socgen/CTT-EZWeb/ezweb-customization/compare/v2.5.6...v2.5.7) (2018-02-05)



<a name="2.5.6"></a>
## [2.5.6](https://sgithub.fr.world.socgen/CTT-EZWeb/ezweb-customization/compare/v2.5.5...v2.5.6) (2018-02-05)



<a name="2.5.5"></a>
## [2.5.5](https://sgithub.fr.world.socgen/CTT-EZWeb/ezweb-customization/compare/v2.5.4...v2.5.5) (2018-01-02)



<a name="2.5.4"></a>
## [2.5.4](https://sgithub.fr.world.socgen/CTT-EZWeb/ezweb-customization/compare/v2.5.3...v2.5.4) (2017-11-23)


### Bug Fixes

* add CSS for row selection ([7064117](https://sgithub.fr.world.socgen/CTT-EZWeb/ezweb-customization/commit/7064117))



<a name="2.5.3"></a>
## [2.5.3](https://sgithub.fr.world.socgen/CTT-EZWeb/ezweb-customization/compare/v2.5.2...v2.5.3) (2017-11-09)


### Features

* **colors:** add more colors ([#9](https://sgithub.fr.world.socgen/CTT-EZWeb/ezweb-customization/issues/9)) ([f3f56a2](https://sgithub.fr.world.socgen/CTT-EZWeb/ezweb-customization/commit/f3f56a2))
* **pkg:** allow sg-bootstrap@3 ([#14](https://sgithub.fr.world.socgen/CTT-EZWeb/ezweb-customization/issues/14)) ([43952e5](https://sgithub.fr.world.socgen/CTT-EZWeb/ezweb-customization/commit/43952e5))



<a name="2.5.2"></a>
## [2.5.2](https://sgithub.fr.world.socgen/CTT-EZWeb/ezweb-customization/compare/v2.5.1...v2.5.2) (2017-04-11)


### Bug Fixes

* **highchart:** fix definition file for highchart ([f091eb7](https://sgithub.fr.world.socgen/CTT-EZWeb/ezweb-customization/commit/f091eb7))



<a name="2.5.1"></a>
## [2.5.1](https://sgithub.fr.world.socgen/CTT-EZWeb/ezweb-customization/compare/v2.5.0...v2.5.1) (2017-03-30)


### Bug Fixes

* set `any` for the definition of config object ([b15c1df](https://sgithub.fr.world.socgen/CTT-EZWeb/ezweb-customization/commit/b15c1df))


### Features

* **highcharts:** add Highcharts configuration ([5e94e95](https://sgithub.fr.world.socgen/CTT-EZWeb/ezweb-customization/commit/5e94e95))



<a name="2.5.0"></a>
# [2.5.0](https://sgithub.fr.world.socgen/CTT-EZWeb/ezweb-customization/compare/v2.5.0-alpha.3...v2.5.0) (2017-02-27)



<a name="2.5.0-alpha.3"></a>
# [2.5.0-alpha.3](https://sgithub.fr.world.socgen/CTT-EZWeb/ezweb-customization/compare/v2.5.0-alpha.2...v2.5.0-alpha.3) (2017-01-26)


### Bug Fixes

* **index:** the module code should stay in ES5 with ES6 modules ([ad5bb4b](https://sgithub.fr.world.socgen/CTT-EZWeb/ezweb-customization/commit/ad5bb4b))



<a name="2.5.0-alpha.2"></a>
# [2.5.0-alpha.2](https://sgithub.fr.world.socgen/CTT-EZWeb/ezweb-customization/compare/v2.5.0-alpha.1...v2.5.0-alpha.2) (2017-01-18)


### Features

* **gulpfile:** copy dts and index file too ([4bb04ff](https://sgithub.fr.world.socgen/CTT-EZWeb/ezweb-customization/commit/4bb04ff))



<a name="2.5.0-alpha.1"></a>
# [2.5.0-alpha.1](https://sgithub.fr.world.socgen/CTT-EZWeb/ezweb-customization/compare/v2.0.4...v2.5.0-alpha.1) (2017-01-18)


### Features

* **pkg:** be module friendly ([94cfd2a](https://sgithub.fr.world.socgen/CTT-EZWeb/ezweb-customization/commit/94cfd2a))
* **README:** indicate support-ezweb-2.0 branch ([ed3d84b](https://sgithub.fr.world.socgen/CTT-EZWeb/ezweb-customization/commit/ed3d84b))



<a name="2.0.4"></a>
## [2.0.4](https://sgithub.fr.world.socgen/CTT-EZWeb/ezweb-customization/compare/v2.0.3...v2.0.4) (2017-01-18)


### Features

* **git:** remove dist files from the repo ([840cf4b](https://sgithub.fr.world.socgen/CTT-EZWeb/ezweb-customization/commit/840cf4b))
* **pkg:** Jenkins release friendly ([894574a](https://sgithub.fr.world.socgen/CTT-EZWeb/ezweb-customization/commit/894574a))



<a name="2.0.4-0"></a>
## [2.0.4-0](https://sgithub.fr.world.socgen/CTT-EZWeb/ezweb-customization/compare/v2.0.3...v2.0.4-0) (2016-09-09)



<a name="2.0.3"></a>
## [2.0.3](https://sgithub.fr.world.socgen/CTT-EZWeb/ezweb-customization/compare/v2.0.2...v2.0.3) (2016-09-09)


### Bug Fixes

* correct usage of ezweb-customization. ([0603726](https://sgithub.fr.world.socgen/CTT-EZWeb/ezweb-customization/commit/0603726))



<a name="2.0.3-0"></a>
## [2.0.3-0](https://sgithub.fr.world.socgen/CTT-EZWeb/ezweb-customization/compare/v2.0.2...v2.0.3-0) (2016-09-09)



<a name="2.0.2"></a>
## [2.0.2](https://sgithub.fr.world.socgen/CTT-EZWeb/ezweb-customization/compare/v2.0.1...v2.0.2) (2016-09-09)


### Bug Fixes

* add .less in build package ([021247c](https://sgithub.fr.world.socgen/CTT-EZWeb/ezweb-customization/commit/021247c))



<a name="2.0.2-0"></a>
## [2.0.2-0](https://sgithub.fr.world.socgen/CTT-EZWeb/ezweb-customization/compare/v2.0.1...v2.0.2-0) (2016-09-09)



<a name="2.0.2-0"></a>
## [2.0.2-0](https://sgithub.fr.world.socgen/CTT-EZWeb/ezweb-customization/compare/v2.0.1...v2.0.2-0) (2016-09-09)



<a name="2.0.1"></a>
## [2.0.1](https://sgithub.fr.world.socgen/CTT-EZWeb/ezweb-customization/compare/v2.0.0...v2.0.1) (2016-09-09)


### Features

* **agGrid:** new customization of agGrid library ([c9e865b](https://sgithub.fr.world.socgen/CTT-EZWeb/ezweb-customization/commit/c9e865b))



