// Yes, I know.
// We don't really need to a clear definition here, and we didn't want to be dependent on the typings module for agGrid or Highcharts.
// cf. discussion on PR #8

export const sgAgGridConfig: any;
export const sgHighchartsConfig: any;
