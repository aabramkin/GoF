/* Module ezweb-customization version 2.5.7 | GIT repository: https://sgithub.fr.world.socgen/CTT-EZWeb/ezweb-customization.git */
/**
 * Initialize AgGrid to be used on AngularJS 1 application.
 **/
agGrid.initialiseAgGridWithAngular1(angular);

/**
 * Create an Angular module that contains the default options for the agGrid.
 **/
angular.module('sg-ag-grid', [])
  .constant('sgAgGridConfig', {
    rowHeight: 39,
    headerHeight: 39,
    icons: {
      // use font-awesome for menu icons
      filter: '<i class="fa fa-filter"/>',
      sortAscending: '<i class="fa fa-long-arrow-down"/>',
      sortDescending: '<i class="fa fa-long-arrow-up"/>',
      // use font-awesome for group expand collapse
      groupExpanded: '<i class="fa fa-minus-square-o"/>',
      groupContracted: '<i class="fa fa-plus-square-o"/>'
    }
  });
