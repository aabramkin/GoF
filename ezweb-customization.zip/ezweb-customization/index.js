//

export var sgGraphColors =  [
  '#e60028', // @red-socgen
  '#23558c', // @blue-sapphire
  '#333333', // @gray-base
  '#35bd5b', // @brand-success
  '#aa8778', // Sandrift
  '#ef694b', // Burnt Sienna
  '#78236e', // Plum
  '#99d1fd', // Anakiwa
  '#dddedf', // @gray-lighter
  '#ffa593', // Mona Lisa
  '#ffc091', // Peach Orange
  '#009bcd'  // @brand-info
]

export var sgAgGridConfig = {
  rowHeight: 39,
  headerHeight: 39,
  icons: {
    // use font-awesome for menu icons
    filter: '<i class="fa fa-filter"/>',
    sortAscending: '<i class="fa fa-long-arrow-down"/>',
    sortDescending: '<i class="fa fa-long-arrow-up"/>',
    // use font-awesome for group expand collapse
    groupExpanded: '<i class="fa fa-minus-square-o"/>',
    groupContracted: '<i class="fa fa-plus-square-o"/>'
  }
}

export var sgHighchartsConfig = {
  colors: [
    '#e60028', // @red-socgen
    '#ffd6b0', // @orange-light
    '#484848',
    '#aa8778',
    '#858585',
    '#d1a694',
    '#ababab'
  ],
  credits: {
    enabled: false
  },
  tooltip: {
    pointFormat: '<span style="color:{series.color}">{series.name}:</span><strong>{point.y}</strong><br />',
    useHTML: true
  }
}
