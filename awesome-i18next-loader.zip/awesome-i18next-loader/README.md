# Awesome i18next loader

 
 [![Build Status](https://cdp-jenkins-sgwebtoolkit.fr.world.socgen/buildStatus/icon?job=SG-Web-Toolkit/awesome-i18next-loader/master)](https://cdp-jenkins-sgwebtoolkit.fr.world.socgen/job/SG-Web-Toolkit/job/awesome-i18next-loader/job/master)


> :tada: Awesome i18next loader for webpack

## Install

```
# for webpack 3
npm install awesome-i18next-loader --dev-save
# for webpack 2
npm install awesome-i18next-loader@2 --dev-save
# for webpack 1
npm install awesome-i18next-loader@1 --dev-save
```

> :warning: For webpack v2, see [the README in the 2.x branch](https://sgithub.fr.world.socgen/SG-Web-Toolkit/awesome-i18next-loader/tree/2.x).  
> :warning: For webpack v1, see [the README in the webpack-1 branch](https://sgithub.fr.world.socgen/SG-Web-Toolkit/awesome-i18next-loader/tree/webpack-1).

## This is not that awesome...

`awesome-i18next-loader` is not that awesome.  
This loader is made to make i18next fit ESM app. To make it work you need to
define a `i18n-config.js` (not restricted name). This file will host the default i18next configuration of your app. You can fix values but some will be
preprocessed by `awesome-i18next-loader`

```js
// example file: `app/i18n-config.js`

const {
  i18next,
  i18nextXHRBackend
} = window

//

i18next
  .use(i18nextXHRBackend)
  .init({
    debug: true,
    lng: 'en',
    fallbackLng: 'en',
    backend: {
      loadPath: 'locales/{{lng}}.json'
    },
    ns: [/* @exec stringify(availableNamespaces) */],
    whitelist: [/* @exec stringify(availableLanguages) */],
    resources: {/* @exec stringify(availableResources) */}
  })
```

- `stringify` is an exposed internal function. It's an alias to [json-stable-stringify](https://www.npmjs.com/package/json-stable-stringify)
- `availableNamespaces` are all the namespaces found after exploring all the locals  
  Example: `['home', 'about']`
- `availableLanguages` are all the languages found after exploring all the locals  
  Example: `['fr', 'en', 'it']`
- `availableResources` content a subset of the full extracted locals content.
  This subset is match the `availableResourcesLanguages`.  
  Example: for `availableResourcesLanguages = ['en', 'fr']`, `availableResources` will content `{'en':{'home':{'hello':'hello'}, 'fr':{'home':{'hello':'bonjour'}}`

Then by requiring this file Webpack will transform it to this :

```js
// example file: `src/i18n-config.js`

const {
  i18next,
  i18nextXHRBackend
} = window

//

i18next
  .use(i18nextXHRBackend)
  .init({
    debug: true,
    lng: 'en',
    fallbackLng: 'en',
    backend: {
      loadPath: 'locales/{{lng}}.json'
    },
    ns: ['hello'],
    whitelist: ['en'],
    resources: {'en':{'hello':{'hello':'hello'}}}
  })
```

For a webpack config like : 

```js
'use strict'

const path = require('path')

//

const awesomeI18nextOptions = {
  globs: [
    // globs
    {
      pattern: '**/locales/**/*.json',
      options: { cwd: 'src' }
    }
  ],
  //
  // The subset exposed to the loader
  // By default, availableResourcesLanguages equal ['en']
  availableResourcesLanguages: ['en']
};

//

module.exports = {
  entry: {
    app: 'src/app.js'
  },
  module: {
    rules: [
      {
        test: /i18n-config\.js$/,
        use: [
          {
            loader: 'awesome-i18next-loader',
            options: awesomeI18nextOptions
          }
        ]
      }
    ]
  }
}
```

<br>
<br>
<br>
<br>

Like i18next will request for json files `awesome-i18next-loader` comes with a plugin named `AwesomeI18nextPlugin`.
This plugin will generate all the local files that i18next might fetch.

For a webpack config like : 

```js
'use strict'

const {AwesomeI18nextPlugin} = require('awesome-i18next-loader')
const path = require('path')

//

const awesomeI18nextOptions = {
  dest: 'locales', // where the locales will be outputed
  globs: [
    // globs
    {
      pattern: '**/locales/**/*.json',
      options: { cwd: 'src' }
    }
  ]
};

//

module.exports = {
  plugins: [
    new AwesomeI18nextPlugin(awesomeI18nextOptions)
  ]
}
```

Now all the locales you have in your `src` folder will be aggregated to one local file for each language.
