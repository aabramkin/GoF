# Change Log

All notable changes to this project will be documented in this file. See [standard-version](https://github.com/conventional-changelog/standard-version) for commit guidelines.

<a name="3.0.0"></a>
# [3.0.0](https://sgithub.fr.world.socgen/dduteil092115/ng-i18next-loader/compare/v3.0.0-5...v3.0.0) (2017-09-28)


### Features

* **loader:** add found locale files as dependency ([#31](https://sgithub.fr.world.socgen/dduteil092115/ng-i18next-loader/issues/31)) ([983f086](https://sgithub.fr.world.socgen/dduteil092115/ng-i18next-loader/commit/983f086))



<a name="3.0.0-5"></a>
# [3.0.0-5](https://sgithub.fr.world.socgen/dduteil092115/ng-i18next-loader/compare/v3.0.0-4...v3.0.0-5) (2017-09-28)



<a name="3.0.0-4"></a>
# [3.0.0-4](https://sgithub.fr.world.socgen/dduteil092115/ng-i18next-loader/compare/v3.0.0-3...v3.0.0-4) (2017-09-28)



<a name="3.0.0-3"></a>
# [3.0.0-3](https://sgithub.fr.world.socgen/dduteil092115/ng-i18next-loader/compare/v3.0.0-2...v3.0.0-3) (2017-09-28)



<a name="3.0.0-2"></a>
# [3.0.0-2](https://sgithub.fr.world.socgen/dduteil092115/ng-i18next-loader/compare/v3.0.0-1...v3.0.0-2) (2017-09-28)



<a name="3.0.0-1"></a>
# [3.0.0-1](https://sgithub.fr.world.socgen/dduteil092115/ng-i18next-loader/compare/v3.0.0-0...v3.0.0-1) (2017-09-28)



<a name="3.0.0-0"></a>
# [3.0.0-0](https://sgithub.fr.world.socgen/dduteil092115/ng-i18next-loader/compare/v1.1.0...v3.0.0-0) (2017-09-28)


### Bug Fixes

* **regex:** adding spaces handling in regexp ([#7](https://sgithub.fr.world.socgen/dduteil092115/ng-i18next-loader/issues/7)) ([#16](https://sgithub.fr.world.socgen/dduteil092115/ng-i18next-loader/issues/16)) ([4d793af](https://sgithub.fr.world.socgen/dduteil092115/ng-i18next-loader/commit/4d793af))


### Features

* **loader:** allow full preprocess use in directive ([#13](https://sgithub.fr.world.socgen/dduteil092115/ng-i18next-loader/issues/13)) ([12bc5ec](https://sgithub.fr.world.socgen/dduteil092115/ng-i18next-loader/commit/12bc5ec))
* **pkg:** update to webpack@2 ([#8](https://sgithub.fr.world.socgen/dduteil092115/ng-i18next-loader/issues/8)) ([8a11155](https://sgithub.fr.world.socgen/dduteil092115/ng-i18next-loader/commit/8a11155))


### BREAKING CHANGES

* **loader:** allow full preprocess use in directive

- Context variable are plain Object now. You need to "stringify" them yourself.

  Before :

  ```js
  i18next
    .use(i18nextXHRBackend)
    .init({
      // [...]
      ns: [/* @echo availableNamespaces */],
      whitelist: [/* @echo availableLanguages */],
      resources: {/* @echo availableResources */}
    })
  ```

  After :

  ```js
  i18next
    .use(i18nextXHRBackend)
    .init({
      // [...]
      ns: [/* @exec stringify(availableNamespaces) */],
      whitelist: [/* @exec stringify(availableLanguages) */],
      resources: {/* @exec stringify(availableResources) */}
    })
  ```

  This change allow you to access properties with native path notation

  Before :

  ```js
  const frResources = {/* @echo availableResources */}['fr'];
  ```

  After :

  ```js
  const frResources = {/* @exec stringify(availableResources.fr) */};
  ```

- It is not possible to pass custom variable to the proprocessing context anymore.

  Before :

  ```js
  const awesomeI18nextOptions = {
    dest: 'locales',
    globs: [{pattern: '**/locales/**/*.json',options: { cwd: 'src' }}],
    // my custom variable
    foo: 'bar'
  };

  //

  '/* @echo foo */' => 'bar'
  ```

  After :

  ```js
  const awesomeI18nextOptions = {
    dest: 'locales',
    globs: [{pattern: '**/locales/**/*.json',options: { cwd: 'src' }}],
    // my custom variable
    foo: 'bar'
  };

  //

  '/* @echo foo */' => '' // ignored
  ```
* **pkg:** update to webpack@2

`awesome-i18next-loader` depends on webpack@2 minimum now...



<a name="2.0.1"></a>
## [2.0.1](https://sgithub.fr.world.socgen/dduteil092115/ng-i18next-loader/compare/v2.0.0...v2.0.1) (2017-08-29)



<a name="2.0.0"></a>
# [2.0.0](https://sgithub.fr.world.socgen/dduteil092115/ng-i18next-loader/compare/v1.1.0...v2.0.0) (2017-08-29)


### Features

* **pkg:** update to webpack[@2](https://github.com/2) (#8) ([8a11155](https://sgithub.fr.world.socgen/dduteil092115/ng-i18next-loader/commit/8a11155))


### BREAKING CHANGES

* **pkg:** update to webpack@2

`awesome-i18next-loader` depends on webpack@2 minimum now...



<a name="1.1.0"></a>
# [1.1.0](https://sgithub.fr.world.socgen/dduteil092115/ng-i18next-loader/compare/v1.0.0...v1.1.0) (2017-01-20)


### Bug Fixes

* **AggregateMetaI18n:** remove sort -1 (#2) ([40d3213](https://sgithub.fr.world.socgen/dduteil092115/ng-i18next-loader/commit/40d3213)), closes [#1](https://sgithub.fr.world.socgen/dduteil092115/ng-i18next-loader/issues/1)


### Features

* **pkg:** prefer to use "npm run release" instead of "npm version/publish" ([2e7e826](https://sgithub.fr.world.socgen/dduteil092115/ng-i18next-loader/commit/2e7e826))
* **pkg:** use standard-version ([070097f](https://sgithub.fr.world.socgen/dduteil092115/ng-i18next-loader/commit/070097f))
* **yarn:** update yarnlock (#4) ([7d07edf](https://sgithub.fr.world.socgen/dduteil092115/ng-i18next-loader/commit/7d07edf))
