//

import { dirname } from 'path'

import { getOptions } from 'loader-utils'
import { preprocess } from 'preprocess'
import stringify from 'json-stable-stringify'
import Debug from 'debug'

import { directiveRegex } from './utils/directiveRegex.js'
import { streamAllGlobs } from './utils/streamAllGlobs.js'
import { MetaI18nDataAdder } from './utils/MetaI18nDataAdder.js'
import { AggregateMetaI18n } from './utils/AggregateMetaI18n.js'

//

const debug = Debug('awesomeI18nextLoader:AwesomeI18nextLoader')
debug('new')

const defaultContext = {
  availableLanguages: [],
  availableNamespaces: [],
  availableResources: {},
  availableResourcesLanguages: ['en'],
}

//

export function AwesomeI18nextLoader(content) {
  debug('transform %s', this.resourcePath)

  const callback = this.async()

  const query = getOptions(this) || {}
  debug('query %j', query)
  debug('query.globs %j', query.globs)
  debug('query.defaultLanguage %s', query.defaultLanguage)

  const root = query.context || this.options.context || process.cwd()
  debug('root %j', root)
  const availableResourcesLanguages =
    query.availableResourcesLanguages ||
    defaultContext.availableResourcesLanguages
  debug(
    'availableResourcesLanguages %j',
    query.availableResourcesLanguages,
    availableResourcesLanguages,
  )

  const metaI18nDataAdder = new MetaI18nDataAdder()
  const aggregateMetaI18n = new AggregateMetaI18n({
    availableResourcesLanguages,
  })

  const matchingFiles = []
  const fileStream = streamAllGlobs(query.globs || [], { root })

  fileStream.on('data', file => matchingFiles.push(file.path))
  const addToLoaderDependencies = filepath => {
    this.addDependency(filepath)

    const dirPath = dirname(filepath)
    this.addContextDependency(dirPath)
  }
  fileStream.once('end', () => {
    debug(`found ${matchingFiles.length} files`)
    this.clearDependencies()
    matchingFiles.forEach(addToLoaderDependencies)
  })

  fileStream
    .pipe(metaI18nDataAdder)
    .pipe(aggregateMetaI18n)
    .on('data', transformEnding)

  function transformEnding(gaveredData) {
    debug('transformEnding %j', gaveredData)
    const context = Object.assign({}, defaultContext, gaveredData)

    context.stringify = stringify

    // HACK(douglasduteil): allow valid preprocessed js
    // Allow preprocess to replace echo on Array and Objects with stringified version
    // - [/* @echo FOO */] => /* @echo FOO */ => []
    // - {/* @echo FOO */} => /* @echo FOO */ => {}
    // - {/* @exec FOO() */} => /* @exec FOO() */ => {}
    content = content.replace(directiveRegex, '/* @$1 $2 */')

    const newContent = preprocess(content, context, 'js')

    callback(null, newContent)
  }
}
