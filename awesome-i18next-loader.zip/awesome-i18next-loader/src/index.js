'use strict'

module.exports = require('./AwesomeI18nextLoader.js').AwesomeI18nextLoader
module.exports.AwesomeI18nextPlugin = require('./AwesomeI18nextPlugin.js').AwesomeI18nextPlugin
