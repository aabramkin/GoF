//

import { Transform } from 'stream'

import Debug from 'debug'
import merge from 'lodash.merge'

//

const debug = Debug('awesomeI18nextLoader:AggregateMetaI18n')

//

export class AggregateMetaI18n extends Transform {
  constructor(options = {}) {
    debug('new', options)

    super({
      objectMode: true,
    })

    this.options = options
    this.availableNamespaces = new Set()
    this.translations = {}
  }

  _transform(file, encoding, callback) {
    if (file.isNull()) {
      return callback(null, file)
    }
    debug('#_transform "%s" file', file.path)
    var i18nMeta = file.i18n

    this.translations[i18nMeta.language] = merge(
      this.translations[i18nMeta.language],
      i18nMeta.translations,
    )

    this.availableNamespaces = new Set([
      ...this.availableNamespaces,
      ...i18nMeta.namespaces,
    ])

    callback()
  }

  _flush(callback) {
    debug('#_flush', this.availableNamespaces)

    const result = {
      availableLanguages: Object.keys(this.translations).sort(),
      availableNamespaces: [...this.availableNamespaces].sort(),
      availableResources:
        pick(this.translations, this.options.availableResourcesLanguages) || {},
    }

    this.push(result)

    callback()
  }
}

//

function pick(collection, tagetKey = []) {
  return Object.keys(collection)
    .filter(key => tagetKey.includes(key))
    .reduce((memo, key) => {
      memo[key] = collection[key]
      return memo
    }, {})
}
