//

import path from 'path'
import { Transform } from 'stream'

import Debug from 'debug'

//

const debug = Debug('awesomeI18nextLoader:MetaI18nDataAdder')

//

export class MetaI18nDataAdder extends Transform {
  constructor() {
    debug('new')
    super({
      objectMode: true,
    })

    this._memo = {}
  }

  _transform(file, encoding, callback) {
    if (file.isNull()) {
      return callback(null, file)
    }

    debug('_transform')

    debug('#ParseJSONLocalFilename "%s" file', file.path)

    var basename = path.basename(file.path, '.json')

    // Find the language
    var language = path.extname(basename) || basename
    var namespaces = []
    var _namespacedData = true

    if (language[0] === '.') {
      // The language is the extension, as in my-namespace.language.json
      language = language.substr(1)
      namespaces = [basename.substr(0, basename.length - language.length - 1)]
      _namespacedData = false
    } else {
      // The language is the basename, as in language.json
      language = basename
    }

    file.i18n = {
      _namespacedData: _namespacedData,
      namespaces: namespaces,
      language: language,
    }

    debug('#ParseJSONLocalFilename result %j', file.i18n)
    debug('#ParseJSONLocalFileContent "%s" file', file.path)

    var i18nMeta = file.i18n
    var parsedContents

    try {
      parsedContents = JSON.parse(file.contents.toString(encoding))
    } catch (e) {
      return callback(
        new Error(
          'Parsing error in the json file : ' + file.path + '\n' + e.stack,
        ),
      )
    }

    if (i18nMeta._namespacedData) {
      i18nMeta.namespaces = Object.keys(parsedContents)
      file.i18n.translations = {}
      file.i18n.translations = parsedContents
    } else {
      file.i18n.translations = {}
      file.i18n.translations[i18nMeta.namespaces[0]] = parsedContents
    }

    this.push(file)
    callback()
  }
}
