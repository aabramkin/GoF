//

import regx from 'regx'

//

// Match opening block comment '/*'
const openBlockComment = /\/\*/
// Match closing block comment '*/'
const closeBlockComment = /\*\//

// Match opening object or array '{' or '['
const openObjectOrArray = /[[{]/
// Match closing object or array '}' or ']'
const closeObjectOrArray = /[\]}]/

// HACK(douglasduteil): allow valid preprocessed js
// Allow preprocess to replace echo on Array and Objects with stringified version
// Inspired by https://github.com/jsoverson/preprocess/blob/v3.1.0/lib/regexrules.js
// - [/* @echo FOO */] => /* @echo FOO */ => []
// - {/* @echo FOO */} => /* @echo FOO */ => {}
// - {/* @exec FOO() */} => /* @exec FOO() */ => {}
export const directiveRegex = regx('g')`
  ${openObjectOrArray}

  \s* // Can have whitespace characters

  ${openBlockComment}

  \s+ // Must at least one whitespace character

  @ // Must have @ character

  // Match any preprocessing directives
  (
    \w+ // matches any word character
  )

  \s+ // Must at least one whitespace character

  // Match any preprocessing directives
  (
    .* //  matches any character
  )

  \s+ // Must at least one whitespace character

  ${closeBlockComment}

  \s* // Can have whitespace characters

  ${closeObjectOrArray}
`
