//

import { Transform } from 'stream'

import Debug from 'debug'
import merge from 'lodash.merge'

//

const debug = Debug('awesomeI18nextLoader:AggregateByLanguage')

//

export class AggregateByLanguage extends Transform {
  constructor() {
    debug('new')
    super({
      objectMode: true,
    })

    this._memo = {}
  }

  _transform(file, encoding, callback) {
    if (file.isNull()) {
      return callback(null, file)
    }
    debug('#_transform "%s" file', file.path)
    var i18nMeta = file.i18n

    this._memo[i18nMeta.language] = merge(
      this._memo[i18nMeta.language],
      i18nMeta.translations,
    )

    callback()
  }

  _flush(callback) {
    debug('#_flush')
    this.push(this._memo)
    callback()
  }
}
