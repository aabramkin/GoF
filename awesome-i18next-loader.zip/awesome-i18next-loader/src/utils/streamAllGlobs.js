//

import path from 'path'

import Debug from 'debug'
import mergeStream from 'merge-stream'
import vfs from 'vinyl-fs'

//

const debug = Debug('awesomeI18nextLoader:streamAllGlobs')

//

export function streamAllGlobs(globs, vfsOptions) {
  const globPattern = ({ pattern, options = {} }) => {
    debug(
      'glob pattern=%j root=%s options=%j',
      pattern,
      vfsOptions.root,
      options,
    )
    return vfs.src(pattern, {
      cwd: path.resolve(vfsOptions.root, options.cwd || ''),
    })
  }

  return mergeStream(...globs.map(globPattern))
}
