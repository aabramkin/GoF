//

import Debug from 'debug'

//

const debug = Debug('awesomeI18nextLoader:LocalFile')

//

export class LocalFile {
  constructor(path, content) {
    debug('new {path %s }', path)
    this.path = path
    this.content = content
  }

  source() {
    return this.content
  }

  size() {
    return Buffer.byteLength(this.source(), 'utf8')
  }
}
