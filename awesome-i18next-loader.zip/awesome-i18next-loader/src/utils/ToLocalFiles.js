//

import { Transform } from 'stream'

import Debug from 'debug'

import { LocalFile } from './LocalFile.js'

//

const debug = Debug('awesomeI18nextLoader:ToLocalFiles')

//

export class ToLocalFiles extends Transform {
  constructor() {
    debug('new')
    super({
      objectMode: true,
    })
  }

  _transform(i18nData, encoding, callback) {
    debug('#_transform %j', i18nData)

    const files = Object.keys(i18nData).map(
      language =>
        new LocalFile(`${language}.json`, JSON.stringify(i18nData[language])),
    )

    callback(null, files)
  }
}
