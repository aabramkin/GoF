//

import path from 'path'

import Debug from 'debug'

import { AggregateByLanguage } from './AggregateByLanguage.js'
import { MetaI18nDataAdder } from './MetaI18nDataAdder.js'
import { streamAllGlobs } from './streamAllGlobs.js'
import { ToLocalFiles } from './ToLocalFiles.js'

//

const debug = Debug('awesomeI18nextLoader:AwesomeI18nextPluginCompilerHook')

//

export class AwesomeI18nextPluginCompilerHook {
  constructor(options) {
    debug('new')
    this.options = options
    this.matchingFiles = []
    this.files = []
  }

  onRun(callback) {
    debug('onRun')

    const onLocalFiles = locals => {
      debug('onLocalFiles')
      this.files = locals
      callback()
    }

    this._getLocaleFiles(onLocalFiles)
  }

  onEmit(compilation, callback) {
    debug('onEmit')
    const { dest } = this.options
    const addToCompilationAssets = file => {
      compilation.assets[`${dest}/${file.path}`] = file
    }
    this.files.forEach(addToCompilationAssets)
    callback()
  }

  onAfterCompile(compilation, callback) {
    debug('onAfterCompile')

    const addToCompilationDependencies = filepath => {
      if (!compilation.fileDependencies.includes(filepath)) {
        debug(
          '#addToCompilationDependencies :\nfileDependencies.push(%s)',
          filepath,
        )
        compilation.fileDependencies.push(filepath)
      }

      const dirPath = path.dirname(filepath)
      if (!compilation.contextDependencies.includes(dirPath)) {
        debug(
          '#addToCompilationDependencies :\ncontextDependencies.push(%s)',
          dirPath,
        )
        compilation.contextDependencies.push(dirPath)
      }
    }

    this.matchingFiles.forEach(addToCompilationDependencies)

    callback()
  }

  //

  _getLocaleFiles(callback) {
    debug('_getLocaleFiles')
    const { globs, root } = this.options

    const metaI18nDataAdder = new MetaI18nDataAdder()
    const toLocalFiles = new ToLocalFiles()
    const aggregateByLanguage = new AggregateByLanguage()

    const streamMatchingFiles = streamAllGlobs(globs, { root })
    streamMatchingFiles.on('data', file => {
      this.matchingFiles = (this.matchingFiles || []).concat([file.path])
    })

    streamMatchingFiles.once('end', file => {
      debug(`found ${this.matchingFiles.length} files`)
    })

    return streamMatchingFiles
      .pipe(metaI18nDataAdder)
      .pipe(aggregateByLanguage)
      .pipe(toLocalFiles)
      .on('data', callback)
  }
}
