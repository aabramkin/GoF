//

import Debug from 'debug'

import { AwesomeI18nextPluginCompilerHook } from './utils/AwesomeI18nextPluginCompilerHook.js'

//

const debug = Debug('awesomeI18nextLoader:AwesomeI18nextPlugin')

//

export class AwesomeI18nextPlugin {
  constructor(options) {
    debug('new %j', options)
    this.options = options
    this._hook = new AwesomeI18nextPluginCompilerHook(options)
  }

  apply(compiler) {
    const _compiler = this._hook
    _compiler.options.root =
      compiler.options.context || this.options.context || process.cwd()
    debug('root', _compiler.options.root)

    compiler.plugin('run', function compilerRun(compiler, callback) {
      debug('compiler#run')
      _compiler.onRun(callback)
    })

    compiler.plugin('watch-run', function(watching, callback) {
      debug('compiler#watch-run')
      _compiler.onRun(callback)
    })

    compiler.plugin('emit', function(compilation, callback) {
      debug('compiler#emit')
      _compiler.onEmit(compilation, callback)
    })

    compiler.plugin('after-compile', function(compilation, callback) {
      // Don't add errors for child compilations
      if (compilation.compiler.isChild()) {
        callback()
        return
      }

      debug('compiler#after-compile')
      _compiler.onAfterCompile(compilation, callback)
    })
  }
}
