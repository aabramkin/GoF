/**
 * @namespace Sticky-header
 *
 * @classdesc The stickyHeader component is applied on a SG-Bootstrap header and provides the animated sticky effect when scrolling towards the bottom of a page.
 *
 * Initialize it like this:
 *
 * **JavaScript**
 *
 * ```javascript
 * $('.topheader').stickyHeader();
 * ```
 *
 */
(function($) {
  var delay = 1000; // (in ms) slide effect happens after this delay

  $.fn.stickyHeader = function() {
    var header = $(this);
    var navbar = header.find('.navbar');

    var stickyNavbar = {
      navbarTimeout: null,
      shouldBeSticky: function(header, scrollTop) {
        return (scrollTop >= header.height() && this.data('sticky') !== true);
      },
      shouldStickyBeRemoved: function(header, scrollTop) {
        return (scrollTop < header.height() && this.data('sticky') === true && $(header).find('.introjs-fixParent').length === 0);
      },
      setSticky: function() {
        var self = this;
        if (!self.navbarTimeout) {
          self.data('sticky', true);
          self.navbarTimeout = setTimeout(function() {
            self.addClass('prepare-sticky-header');
            self.css('top'); // force browser redraw to trigger CSS transition
            self.addClass('transition sticky-header');
          }, delay);
        }
      },
      removeSticky: function() {
        if (this.navbarTimeout) {
          clearTimeout(this.navbarTimeout);
          this.navbarTimeout = null;
        }
        this.data('sticky', false);
        this.removeClass('prepare-sticky-header sticky-header');
        this.removeClass('transition');
      }
    };

    // extend navbar API
    $.extend(navbar, stickyNavbar);

    function onScroll() {
      var scrollTop = $(window).scrollTop();
      if (navbar.shouldBeSticky(header, scrollTop) === true) {
        navbar.setSticky();
      }
      else if (navbar.shouldStickyBeRemoved(header, scrollTop) === true) {
        navbar.removeSticky();
      }
    }

    if (window.addEventListener) {
      window.addEventListener('scroll', onScroll);
    } else { // IE8
      window.attachEvent('onscroll', onScroll);
    }
  };
}(jQuery));
