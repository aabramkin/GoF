/**
 * @namespace Slider
 *
 * @classdesc The slider component is applied on a SG-Bootstrap slider.
 *
 * Initialize it like this:
 *
 * **JavaScript**
 *
 * ```javascript
 * $('.mySlider').sgbSlider();
 * ```
 */
(function($) {
    var SliderHandle = function (value, whereAppend, triggerChange, config) {
        var self = this;
        self.$elem = $(document.createElement('div'));
        self.$elem.addClass('slider-handle');
        self.$parent = whereAppend;
        self.value = value;
        self.disabled = false;
        self.triggerChange = triggerChange;
        self.active = true;
        if (config.ticks){
            self.$elem.addClass('range');
        }
        if (value === 0){
            self.positionInPercentage = 0;
        } else {
            self.positionInPercentage = (((value - config.min) / (config.max - config.min)) * 100) ;
        }
        self.config = {
            min: config.min,
            max: config.max,
            step: config.step
        };
        self.$elem.css({
            left: self.positionInPercentage + '%'
        });
        self.$parent.append(self.$elem);
        self.$elem.on('mousedown touchstart', function(event) {
            self.mouseDown(event);
        });
        return self;
    };
    SliderHandle.prototype = {
        setPositionInPercentage: function(value) {
            var self = this;
            // Do nothing if the new position is not different
            if (value === self.positionInPercentage) {
                return;
            }
            self.positionInPercentage = Math.floor(value);
            self.$elem.css({
                left: self.positionInPercentage + '%'
            });
        },
        setPosition: function(value) {
            var self = this;
            self.setValue(self.valueFromMousePositionX(value));
        },
        setValue: function(value) {
            var self = this;
            if (self.active) {
                if (value !== self.value){
                    self.triggerChange(self.value);
                }
                self.value = self.rangeValue(value);
                // Update the position of the handle
                self.setPositionInPercentage(self.valueToPercentage(value));
            }
        },
        rangeFromHandlesPosition: function () {
            var self = this;
            self.setWidthInPercentage(self.positionInPercentage);
        },
        setWidthInPercentage: function(value) {
            var self = this;
            // Do nothing if the new width is not different
            if (value === self.widthInPercentage) {
                return;
            }
            self.widthInPercentage = Math.floor(value);
        },
        rangeValue: function(value) {
            var self = this;
            return Math.min(Math.max(value, self.config.min), self.config.max);
        },
        valueToPercentage: function(value) {
            var self = this;
            return (self.scaleValue(value) / self.valueRange()) * 100;
        },
        valueFromMousePositionX: function(mousePositionX) {
            var self = this;
            return self.scaleValue(self.rawValue(mousePositionX));
        },
        scaleValue: function(value) {
            var self = this;
            return Math.floor(value / self.config.step) * self.config.step;
        },
        rawValue: function(mousePositionX) {
            var self = this;
            return Math.max(0, Math.min(1, self.rawProportion(mousePositionX))) * self.valueRange();
        },
        rawProportion: function(mousePositionX) {
            var self = this;
            return self.diffInPixel(mousePositionX) / self.$parent.width();
        },
        diffInPixel: function(positionX) {
            var self = this;
            return positionX - self.$parent.offset().left;
        },
        valueRange: function() {
            var self = this;
            return self.config.max - self.config.min;
        },
        mouseDown: function (event) {
            var self = this;
            if (!self.disabled){
                event.preventDefault();
                $(document).on('mousemove touchmove', self.mouseMove.bind(self));
                $(document).on('mouseup touchend', self.mouseUp);
            }
        },
        mouseUp: function () {
            $(document).unbind('mousemove touchmove');
            $(document).unbind('mouseup touchend');
        },
        mouseMove: function () {
            var self = this;

            // HACK(dduteil092115): explicit use of window.event
            // I hate this code :(
            // Sadly to maximize the legacy compatibility, I explicitly doing
            // the same wrong doing... sry
            var originalEvent = window.event.originalEvent || window.event;
            var touches = originalEvent.touches && originalEvent.touches.length ? originalEvent.touches : [originalEvent];
            var event = (originalEvent.changedTouches && originalEvent.changedTouches[0]) || touches[0];
            if (self.active) {
                var oldValue = self.value;
                self.setPosition(event.pageX);
                // Make updates only if the value has really changed
                if (self.value !== oldValue) {
                    self.rangeFromHandlesPosition();
                }
            }
        },
        disable: function () {
            var self = this;
            self.disabled = true;
        },
        enable: function () {
            var self = this;
            self.disabled = false;
        }
    };

    var SgbSlider = function (elem, options) {
        var self = this;
        self.elem = elem;
        self.$elem = $(elem);
        self.options = options;
        self.handles = [];
        self.defaults = {
            ticks: false,
            color: null,
            range: false,
            min: 0,
            max: 100,
            value: 0,
            step: 1,
            values: [0,100]
        };
        self.config = $.extend({}, self.defaults, self.options);
    };
    SgbSlider.prototype = {
        init: function () {
            var self = this;
            self.$elem.addClass('slider');
            if (self.config.color){
                self.$elem.addClass(self.config.color);
            }
            self.createRangeBar();
            if (self.config.ticks){
                self.createTicks();
            }
            if (self.config.range) {
                var handle1 = new SliderHandle(self.config.values[0], self.$elem, self.slideChange, self.config);
                var handle2 = new SliderHandle(self.config.values[1], self.$elem, self.slideChange, self.config);
                self.handles.push(handle1, handle2);
                self.$elem.on('mousedown touchstart', function (event) {
                    self.mouseDown(event);
                });
            } else {
                var handle = new SliderHandle(self.config.value, self.$elem, self.slideChange, self.config);
                self.handles.push(handle);
                self.$elem.on('mousedown touchstart', function (event) {
                    self.mouseDown(event);
                });
            }
            self.setRangeBar();
            self.$elem.trigger('slider:create', ['The slider is created !']);
            return self;
        },
        createTicks: function () {
            var self = this;
            var numberTicks = (self.config.max - self.config.min) / self.config.step;
            for (var i = 1; i<numberTicks; i++) {
                var tick = $(document.createElement('span'));
                tick.addClass('slider-tick');
                tick.css({
                    left: (100 / numberTicks) * i + '%'
                });
                self.$elem.append(tick);
            }
        },
        mouseDown: function (event) {
            var self = this;
            event.preventDefault();
            $(window).on('mousemove touchmove', self.mouseMove.bind(self));
            $(window).on('mouseup touchend', self.mouseUp);
        },
        mouseUp: function () {
            $(document).unbind('mousemove touchmove');
            $(document).unbind('mouseup touchend');
        },
        setRangeBar: function (){
            var self = this;
            if (self.config.range){
                if (self.handles[0].positionInPercentage <= self.handles[1].positionInPercentage) {
                    self.rangeBar.css({
                        width: (100 - self.handles[0].positionInPercentage) - (100 - self.handles[1].positionInPercentage) + '%',
                        left: self.handles[0].positionInPercentage + '%'
                    });
                } else {
                    self.rangeBar.css({
                        width: (100 - self.handles[1].positionInPercentage) - (100 - self.handles[0].positionInPercentage) + '%',
                        left: self.handles[1].positionInPercentage + '%'
                    });
                }
            } else {
                self.rangeBar.css({
                    width: self.handles[0].positionInPercentage + '%'
                });
            }
        },
        mouseMove: function () {
            var self = this;
            self.setRangeBar();
        },
        createRangeBar: function(){
            var self = this;
            self.rangeBar = $(document.createElement('div'));
            self.rangeBar.addClass('slider-range-bar');
            self.$elem.append(self.rangeBar);
        },
        activate: function(active) {
            var self = this;
            if (active) {
                self.$elem.attributes.$addClass('active');
            }
            else {
                self.$elem.attributes.$removeClass('active');
            }
            self.$elem.active = active;
        },
        slideChange: function (value) {
            var self = this;
            self.$elem.trigger('slider:slide', [value]);
        },
        setValue: function (value, handle) {
            var self = this;
            handle = handle - 1;
            if (self.config.range){
                self.handles[handle].setValue(value);
            } else {
                self.handles[0].setValue(value);
            }
            self.setRangeBar();
        },
        disable: function (handle) {
            var self = this;
            handle = handle - 1;
            if (self.config.range){
                self.handles[handle].disable();
            } else {
                self.handles[0].disable();
            }
        },
        enable: function (handle) {
            var self = this;
            handle = handle - 1;
            if (self.config.range){
                self.handles[handle].enable();
            } else {
                self.handles[0].enable();
            }
        }
    };

    /**
     * @memberOf Slider
     *
     * @param {object} options
     * @param {boolean} options.ticks default: false
     * @param {string} options.color default:null => can be primary, primary-alt
     * @param {boolean} options.range default : false
     * @param {boolean} options.disabled default: false
     * @param {number} options.min default: 0
     * @param {number} options.max default: 100
     * @param {number} options.value default: 0 => start value if it isn't range
     * @param {number} options.step default: 1
     * @param {number} options.values default: [0-100] => start values if it's range
     * @param handle apply method option in specific handle
     * @param value  set handle value
     */

    $.fn.sgbSlider = function (options, handle, value) {
        return this.each(function () {
            if (typeof options === 'object' || !options) {
                if (!this.slider) {
                    this.slider = new SgbSlider(this, options);
                    this.slider.init();
                }
            } else if (typeof options === 'string' &&
                options === 'setValue'){
                this.slider.setValue(value, handle);
            } else if (typeof options === 'string' &&
                options === 'disable') {
                this.slider.disable(handle);
            }
        });
    };
}(jQuery));
