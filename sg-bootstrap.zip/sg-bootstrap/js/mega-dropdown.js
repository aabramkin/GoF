/**
 * @namespace Mega-dropdown
 *
 * @classdesc The megaDropdown component is an enhanced version of [Bootstrap dropdown](http://getbootstrap.com/components/#dropdowns).
 *
 * It provides the following additional features:
 *
 * * Centered if its default positioning is displaying it outside of the screen
 * * Can be opened by on mouse hover, if the option is enabled
 *
 * Initialize it like this:
 *
 * **HTML**
 *
 * ```html
 * <ul class="nav navbar-nav">
 *  <li><a href="#">Home</a></li>
 *    <li class="dropdown dropdown-mega">
 *      <a class="dropdown-toggle" data-toggle="dropdown" href="">
 *        Menu title
 *        <span class="caret"></span>
 *      </a>
 *      <ul class="dropdown-menu col-md-8 col-sm-8">
 *        <li>
 *          <div class="row">
 *            <div class="col-md-3 col-sm-4">
 *              <h1>Title</h1>
 *              <ul>
 *                <li class="dropdown-header">Header</li>
 *                <li><a href="#">Menu item 1</a></li>
 *                 <li><a href="#">Menu item 2</a></li>
 *                <!-- you can add more menu items here -->
 *              </ul>
 *            </div>
 *            <div class="col-md-3 col-sm-4">
 *              <!-- other column, with other header or menu items -->
 *            </div>
 *          </div>
 *        </li>
 *      </ul>
 *    </li>
 *   </li>
 * </ul>
 * ```
 *
 * **JavaScript**
 *
 * ```javascript
 * $('.dropdown-mega').megadropDown();
 * ```
 */
(function($) {
  // In pixels, arrow offset used to position the arrow under the navbar item
  var defaultArrowOffset = 15;

  // In pixels, the number of pixel at which the navbar will transform to/from responsive mode
  var navbarCollapseAt = 750;

  // In milliseconds, delay after which the megamenu will show/hide on mouseenter/mouseleave
  var hoverDelay = 300;
  var endHoverDelay = 300;

  /**
   * @memberOf Mega-dropdown
   * @param {object} options For now, the only option is `open`.
   *
   * Specify `{open: 'hover'}` to enable the opening/hiding of the mega dropdown when you designate a menu with à pointing device.
   */
	$.fn.megaDropdown = function(options) {
    this.options = options;
    this.open = null;

    var $menuContainers = $(this);
    var defaultMenuLeftMargin;
    var howMenuHasBeenOpened = null;
    var activeDelay = null;
    $menuContainers.options = options || [];

    defaultMenuLeftMargin = getMarginFromFirstMenu($menuContainers);

    function getMarginFromFirstMenu($menuContainers) {
      var firstMenu = $menuContainers.first().find('> ul.dropdown-menu');
      return firstMenu.css('margin-left');
    }

    $menuContainers.each(function() {
			var $menuContainer = $(this);
      initMenu($menuContainer);
		});

    function initMenu($menuContainer) {
      var $navbarItem = $menuContainer.find('> a.dropdown-toggle');
      var $menu = $menuContainer.find('> ul.dropdown-menu');

      hideMenu($menu);
      $navbarItem.on('click.bs.dropdown', onNavbarItemClicked($menu));
      $(window).on('optimizedResize', onNavbarItemClicked($menu));
      $menuContainer.on('click', onMenuContainerClicked);
      if($menuContainers.options.open == 'hover'){
        $navbarItem.on('mouseenter', onNavbarItemHover($menu, $navbarItem));
        $menuContainer.on('mouseleave', onMenuContainerLeave($menu, $navbarItem));
        $navbarItem.on('mouseleave', onNavbarItemLeave($menu, $navbarItem));
      }
    }

    function hideMenu($menu) {
      $menu.css('visibility', 'hidden');
      $menu.css('width', '');
    }

		function onNavbarItemClicked($menu) {
			return function(event) {
        if (isMenuOpened($menu) && howMenuHasBeenOpened === 'hover') {
          var $clickedElement = $(event.target);
          if ($clickedElement.hasClass('dropdown-toggle') ||  $clickedElement.hasClass('caret')) {
            event.preventDefault();
          }
          event.stopPropagation();
        }
        else {
          /*
          this setTimeout is used to wait for the browser rendering engine to display the menu
          otherwise the jQuery offset() method used below will not return the proper values
          */
          setTimeout(executeAfterMenuHasBeenRendered($menu), 0);
        }
			}
		}

    function isMenuOpened($menu) {
      return $menu.parent().hasClass('open');
    }

    function executeAfterMenuHasBeenRendered($menu) {
      return function() {
        var $arrow;

        removeArrowIfNeeded($menu);
        resetMenu($menu);

        if (isMenuOpened($menu)) {
          if (!isNavbarCollapsed()) {
            if(isMenuOutOfContainer($menu)){
              resizeMenu($menu);
              centerMenu($menu);
            }

            $arrow = createArrow($menu);
            if (isMenuOutOfWindow($menu)) {
              centerMenu($menu);
            }
            positionArrow($arrow, $menu);
          }
          showMenu($menu);
        }
        else {
          hideMenu($menu);
          howMenuHasBeenOpened = null;
        }
      }
    }

    function removeArrowIfNeeded($menu) {
      var $arrow = $menu.find('div.arrow');
      if ($arrow.length > 0) {
        $arrow.remove();
      }
    }

    function resetMenu($menu) {
      var position = (isNavbarCollapsed()) ? 'static' : 'absolute';
      $menu.css('left', 'auto');
      $menu.css('position', position);
      $menu.css('margin-left', defaultMenuLeftMargin);
    }

    function isNavbarCollapsed() {
      return ($(window).width() <= navbarCollapseAt);
    }

    function createArrow($menu) {
      var $arrow = $('<div class="arrow"></div>');
      $menu.prepend($arrow);
      return $arrow;
    }

    function isMenuOutOfWindow($menu) {
      var windowWidth = $(window).width();
      var menuLeftOffset = getMenuLeftOffset($menu);
      var menuRightOffset = getMenuRightOffset($menu);
			return (menuLeftOffset <= 0 || menuRightOffset >= windowWidth);
		}

    function isMenuOutOfContainer($menu){
      var $container = $('.navbar .container');
      var containerLeftOffset = getContainerLeftOffset($container);
      var containerRightOffset = getContainerRightOffset($container);
      var menuLeftOffset = getMenuLeftOffset($menu);
      var menuRightOffset = getMenuRightOffset($menu);
      return (menuLeftOffset <= containerLeftOffset || menuRightOffset > containerRightOffset);
    }

    function getMenuLeftOffset($menu) {
      return $menu.offset().left;
    }

    function getMenuRightOffset($menu) {
      var menuWidth = $menu.outerWidth();
      var menuLeftOffset = getMenuLeftOffset($menu);
      return Math.ceil(menuLeftOffset + menuWidth);
    }

    function getContainerLeftOffset($container){
      return $container.offset().left;
    }

    function getContainerRightOffset($container){
      var containerWidth = $container.width();
      var containerLeftOffset = getContainerLeftOffset($container);
      return Math.ceil(containerLeftOffset + containerWidth);
    }

    function resizeMenu($menu) {
      var $container = $('.navbar .container');
      $menu.css('width', $container.css('width'));
    }

    function centerMenu($menu) {
      $menu.css('left', '50%');
      $menu.css('position', 'absolute');
      $menu.css('margin-left', -Math.abs($menu.outerWidth()/2));
		}

    function positionArrow($arrow, $menu) {
      $arrow.css('left', getArrowOffset($menu));
		}

    function getArrowOffset($menu) {
      var $navbarItem = $menu.parent().find('> a.dropdown-toggle');
      var arrowOffset = Math.ceil($navbarItem.offset().left - $menu.offset().left + parseInt($navbarItem.css('padding-left').replace('px', ''), 10) + defaultArrowOffset);
      return applyArrowConstraints(arrowOffset, $menu);
    }

    function applyArrowConstraints(offset, $menu) {
      var menuWidth = $menu.width();
      if (offset < 0) {
        offset = defaultArrowOffset;
      }
      else if (offset > menuWidth) {
        offset = menuWidth - defaultArrowOffset;
      }
      return offset.toString() + 'px';
    }

    function showMenu($menu) {
      $menu.css('visibility', 'visible');
    }

    function onMenuContainerClicked(event) {
      var $clickedElement = $(event.target);
      if ($clickedElement.prop('tagName') !== 'A' && $clickedElement.prop('tagName') !== 'BUTTON' && !$clickedElement.hasClass('caret')) {
        event.preventDefault();
        event.stopPropagation();
      }
    }

    function onNavbarItemHover($menu, $navbarItem) {
      return function() {
        if (!isNavbarCollapsed()) {
          activeDelay = setTimeout(function() {
            if (!isMenuOpened($menu)) {
              howMenuHasBeenOpened = 'hover';
              $($navbarItem).click();
              activeDelay = null;
            }
          }, hoverDelay);
        }
      }
    }

    function onMenuContainerLeave($menu, $navbarItem) {
      return function() {
        if (!isNavbarCollapsed()) {
          howMenuHasBeenOpened = null;
          activeDelay = setTimeout(function() {
            if (isMenuOpened($menu)) {
              $($navbarItem).click();
              $($navbarItem).blur(); // lose focus on menu mouse leave
              activeDelay = null;
            }
          }, endHoverDelay);
        }
      }
    }

    function onNavbarItemLeave($menu, $navbarItem) {
      return function() {
        if(activeDelay !== null){
          clearTimeout(activeDelay);
        }
      }
    }

    function throttle(type, name, obj) {
        var obj = obj || window;
        var running = false;
        var func = function() {
            if (running) { return; }
            running = true;
            requestAnimationFrame(function() {
                obj.dispatchEvent(new CustomEvent(name));
                running = false;
            });
        };
        obj.addEventListener(type, func);
    };

    throttle("resize", "optimizedResize");
	};
}(jQuery));
