/**
 * @namespace Switch
 *
 * @classdesc The switch component is applied on a SG-Bootstrap switch.
 *
 * Initialize it like this:
 *
 * **JavaScript**
 *
 * ```javascript
 * $('.mySwitch').sgbSwitch();
 * ```
 */
(function ($) {
    var SgbSwitch = function (elem, options) {
        var self = this;
        self.elem = elem;
        self.$elem = $(elem);
        self.options = options;
        self.defaults = {
            type: 'default',
            isChecked: false,
            textOn: 'On',
            textOff: 'Off',
            iconOn: 'fa fa-check',
            iconOff: 'fa fa-close',
            onChange: null
        };
        self.config = $.extend({}, self.defaults, self.options);
    };

    SgbSwitch.prototype = {
        init: function () {
            var self = this;
            self.constructMarkup();
            self.$elem.append(self.template);
            if (self.config.isChecked) {
                self.switchOn();
            }
            self.$elem.click(function (event) {
                    if (event.target.localName === 'input' ||
                        (event.target.localName === 'div' &&
                        $(event.toElement).attr('class') === undefined)) {
                        self.toggle();
                    }
                }
            );
            return self;
        },
        constructMarkup: function () {
            var self = this;
            switch (self.config.type) {
                case 'toggle':
                    self.template = '<div class="switch">' +
                        '<div class="switch-container">' +
                        '<label>' +
                        '<span class="switch-label-on">' + self.config.textOn + '</span>' +
                        '<input type="checkbox"><span></span>' +
                        '<span class="switch-label-off">' + self.config.textOff + '</span>' +
                        '</label>' +
                        '</div>' +
                        '</div>';
                    break;
                case 'toggleIcon':
                    self.template = '<div class="switch">' +
                        '<div class="switch-container">' +
                        '<label>' +
                        '<span class="switch-label-on"><i class="' + self.config.iconOn + '"></i></span>' +
                        '<input type="checkbox">' +
                        '<span></span>' +
                        '<span class="switch-label-off"><i class="' + self.config.iconOff + '"></i></span>' +
                        '</label>' +
                        '</div>' +
                        '</div>';
                    break;
                default:
                    self.template = '<div class="switch">' +
                        '<div>' + self.config.textOff + '</div>' +
                        '<div class="switch-container">' +
                        '<label><input type="checkbox"><span></span></label>' +
                        '</div><div>' + self.config.textOn + '</div>' +
                        '</div>';
                    break;
            }
        },
        switchOn: function () {
            var self = this;
            self.config.isChecked = true;
            self.$elem.find('input').prop('checked', true);
            self.$elem.find('.switch-container').addClass('active');
        },
        switchOff: function () {
            var self = this;
            self.config.isChecked = false;
            self.$elem.find('input').prop('checked', false);
            self.$elem.find('.switch-container').removeClass('active');
        },
        toggle: function () {
            var self = this;
            if (!self.config.isChecked) {
                self.switchOn()
            } else {
                self.switchOff()
            }
            self.emitChange();
        },
        emitChange: function () {
            var self = this;
            if (self.config.onChange) {
                self.config.onChange(self.config.isChecked);
            }
        }
    };

    /**
     * @memberOf Switch
     *
     * @param {object} options
     * @param {string} options.type default: 'default'
     * @param {boolean} options.isChecked default:false
     * @param {string} options.textOn default: 'On'
     * @param {string} options.textOff default: 'Off'
     * @param {string} options.iconOn default: 'fa fa-check'
     * @param {string} options.iconOff default: 'fa fa-close'
     * @param {function} options.onChange This function has one parameter, which is the changed value
     */

    $.fn.sgbSwitch = function (options) {
        return this.each(function () {
            if (typeof options === 'object' || !options) {
                if (!this.switcher){
                    this.switcher = new SgbSwitch(this, options);
                    this.switcher.init();
                }
            }
            else if (typeof options === 'string' &&
                typeof this.switcher[options] === 'function') {
                this.switcher[options]();
            }
        });
    };
})(jQuery);
