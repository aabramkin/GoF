# CKEditor skins

This directory contains skins for the [CKEditor component](http://ckeditor.com/).
Read below to know how to integrate it in your application.

## For EzWeb applications

EzWeb build process can copy the files for you.
In the `tasks/configuration/project-dependencies-list.js` file, add the following lines:

```js
  specificAssets: [
    {
      source: 'node_modules/sg-bootstrap/ckeditor-skins/dark/*.*',
      dest: config.dest.hash + '/vendor/ckeditor/skins',
      base: 'node_modules/sg-bootstrap/ckeditor-skins'
    },
```


## For other web-applications

Simply copy the skin directory in the `ckeditor/skins` directory of your application.
